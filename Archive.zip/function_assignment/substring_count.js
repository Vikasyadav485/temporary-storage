/*
  Write a function that counts the occurrence of a substring in a string

  Examples:
    occurrences('hello world', 'l') => 3
    occurrences('hello world', 'll') => 1
    occurrences('hello world', 'world') => 1
    occurrences('hello world', 'zebra') => 0

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function isSubstringAt(string, subString, position) {
  for (let index = 0; index < subString.length; index++) {
    if (subString[index] !== string[position + index]) {
      return false;
    }
  }
  return true;
}

function occurrences(string, substring) {
  // Implementation here.
  let count = 0;
  for (let index = 0; index < string.length; index++) {
    if (substring[0] === string[index] && isSubstringAt(string, substring, index)) {
      count++;
    }
  }
  return count;
}

function composeMessege(actualValue, expectedValue) {
  const result = actualValue === expectedValue ? "✅" : "❌";
  let messege = result + " It Should be " + expectedValue;
  messege += " and it is " + actualValue;
  console.log(messege);
}

function testOccurences(a, b, e) {
  const actualValue = occurrences(a, b);
  composeMessege(actualValue, e);
}

function testall() {
  testOccurences("hello worlld", "ll", 2);
  testOccurences("October November December", "ber", 3);
  testOccurences("Hare Ram Hare Ram Ram Ram Hare Hare", "Ram", 4);
  testOccurences("Fuzzy Wuzzy was a bear, Fuzzy Wuzzy had no hair, Fuzzy Wuzzy wasn't very Fuzzy", "Fuzzy", 4);
  testOccurences("October November December", "", 0);
  testOccurences("hahahaha ha", "haha", 3);
}

testall();