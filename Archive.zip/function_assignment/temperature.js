/*
  Write a function that converts temperature from one unit to another

  Function takes three arguments: `from`, `to`, `value`
  
  `from` and `to` can have following values:
    - C
    - F
    - K

  Here C means Celsius, K is Kelvin and F is Fahrenheit

  Examples:
    convert('C', 'K', 0) => 273.15
    convert('C', 'F', 37) => 98.6
    convert('F', 'K', 98.6) => 310.15
    convert('F', 'C', -40) => -40
    convert('K', 'C', 100) => -173.15
    convert('K', 'F', 100) => -279.67

  Here are the conversion formulae in case you wonder how it is done :)
    - F to C:
      (F − 32) × 5/9 = C
    - K to C:
      K − 273.15 = C

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function cToK(a) {
  return a + 273.15;
}

function kToC(a) {
  return a - 273.15;
}

function cToF(a) {
  return 9 * a / 5 + 32;
}

function fToC(a) {
  return (a - 32) * 5 / 9;
}

function fToK(a) {
  return fToC(a) + 273.15;
}

function kToF(a) {
  return cToF(kToC(a));
}

function convert(from, to, value) {
  value = value * 1;
  // Implementation here.
  if (from === to) {
    return value;
  }
  let convertedValue = value;
  const conversion = from + "" + to;

  switch (conversion) {
    case "CK":
      convertedValue = cToK(value);
      return convertedValue;
    case "KC":
      convertedValue = kToC(value);
      return convertedValue;
    case "CF":
      convertedValue = cToF(value);
      return convertedValue;
    case "FC":
      convertedValue = fToC(value);
      return convertedValue;
    case "KF":
      convertedValue = kToF(value);
      return convertedValue;
    case "FK":
      convertedValue = fToK(value);
      return convertedValue;
    default: 
      return NaN;
  }
}

function isApprox(a, b) {
  let c = a - b;
  c = (c > 0) ? c : c * (-1);
  return c < 0.05;
}

function composeMessege(actualValue, expectedValue) {
  const result = isApprox(actualValue, expectedValue) ? "✅" : "❌";
  const messege = result + " It Should be " + expectedValue + " and it is " + actualValue;
  console.log(messege);
}

function testConvertedTemperature(a, b, c, e) {
  const actualValue = convert(a, b, c);
  composeMessege(actualValue, e);
}

function testall() {
  testConvertedTemperature("C", "F", "0", 32);
  testConvertedTemperature("C", "K", 5, 278.15);
  testConvertedTemperature("K", "F", 8, -445.27);
  testConvertedTemperature("F", "K", 1, 255.928); 
  testConvertedTemperature("F", "C", 234, 112.222);
  testConvertedTemperature("F", "F", 32, 32);
  testConvertedTemperature("E", "F", 32, NaN);
}

testall();