/*
  Write a function that tells if a string ends with a specific substring

  Examples:
    endsWith('hello world', 'ld') => true
    endsWith('hello world', 'wor') => false
    endsWith('hello world', 'hello') => false

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function isSubstringAt(string, subString, position) {
  for (let index = 0; index < subString.length; index++) {
    if (subString[index] !== string[position + index]) {
      return false;
    }
  }
  return true;
}

function endsWith(string, subString) {
  if (subString === "") {
    return false;
  }
  return isSubstringAt(string, subString, string.length - subString.length);
}

function composeMessege(string, subString, actualValue, expected) {
  const check = actualValue === expected ? "👍🏻" : "👹";
  let messege = check + "[ " + string + ", " + subString + "]";
  messege += " | actual value : " + actualValue;
  messege += " | expected value : " + expected + " |";

  return messege;
}

function testEndsWith(string, subString, expected) {
  const actualValue = endsWith(string, subString);
  const messege = composeMessege(string, subString, actualValue, expected);
  console.log(messege);
}

function testall() {
  testEndsWith("hello world.net", "net", true);
  testEndsWith("hello world entry", "try", true);
  testEndsWith("hello world entry", "", false);
  testEndsWith("hello world entry", "try", true);
  testEndsWith("hello world entry", "try", true);
}

testall();