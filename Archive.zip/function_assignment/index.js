/*
  Implement the below function to find the first index of a character
  Return -1 if the target character is absent 

  Examples:
    findIndex('hello world', 'o') => 4
    findIndex('repeating iiiiiiii', 'i') => 6
    findIndex('not found', 'z') => -1

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function findIndex(text, target) {
  // Implementation here.
  for (let index = 0; index < text.length; index++) {
    if (target === text[index]) {
      return index;
    }
  }
  return - 1;
}

function composeMessege(actualValue, expectedValue) {
  const result = actualValue === expectedValue ? "✅" : "❌";
  const messege = result + " It Should be " + expectedValue + " and it is " + actualValue;
  console.log(messege);
}

function testIndex(text, target, e) {
  const actualValue = findIndex(text, target);
  composeMessege(actualValue, e);
}

function testall() {
  testIndex("Ram manohar", "n", 6);
  testIndex("Murali Manohar ThD college", "h", 11);
  testIndex("Guru Granth Sahib", "t", 9);
  testIndex("Please use the access card.", ".", 26);
  testIndex("To open the door.", "d", 12);
  testIndex("To open the door.", "a", -1);
  testIndex("To open the door.", "", -1);
}

testall();