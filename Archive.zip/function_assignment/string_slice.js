/*
  Implement the below function that
  creates a slice/substring using start and end indices

  Examples:
    slice('hello world', 0, 4) => 'hello'
    slice('negative start', -1, 8) => 'negative '
    slice('', 0, 10) => ''

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function slice(text, start, end) {
  // Implementation here.
  let newWord = "";

  start = start < 0 ? 0: start;
  end = end >= text.length ? text.length - 1: end;

  for (let character = start; character <= end; character++) {
    newWord = newWord + text[character];
  }
  return newWord;
}

function composeMessege(actualValue, expectedValue) {
  const result = actualValue === expectedValue ? "✅": "❌";
  let messege = result + " It Should be " + expectedValue;
  messege += " and it is " + actualValue;
  console.log(messege);
}

function testSlicedString(a, b, c, e) {
  const actualValue = slice(a, b, c);
  composeMessege(actualValue, e);
}

function testall() {
  testSlicedString("Mahabharat", 4, 9, "bharat");
  testSlicedString("prasannavada nay", 10, 20, "da nay");
  testSlicedString("mohandeep", 5, 6, "de");
  testSlicedString("Nareal", 2, 5, "real");
  testSlicedString("Nareal", -1, 3, "Nare");
  testSlicedString("Nareal", 8, 12, "");
  testSlicedString("", 1, 3, "");
  testSlicedString("end is equal to length", 3, 22, " is equal to length");
}

testall();