/*
  Write a function that takes an integer as input and returns a string.

  If the integer is divisible by 3, return "fizz".
  If the integer is divisible by 5, return "buzz".
  If the integer is divisible by both 3 and 5, return "fizzbuzz".
  Otherwise, return the integer as a string.

  Examples:
    fizzBuzz(3) => "fizz"
    fizzBuzz(5) => "buzz"
    fizzBuzz(15)=> "fizzbuzz"
    fizzBuzz(7) => "7"
  
  **There won't be any negative numbers**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function fizzBuzz(number) {
  // Implementation here.
  if (number % 15 === 0) {
    return "fizzbuzz";
  }
  if (number % 5 === 0) {
    return "buzz";
  }
  if (number % 3 === 0) {
    return "fizz";
  }
  return "" + number;
}

function composeMessege(actualValue, expectedValue) {
  const result = actualValue === expectedValue ? "✅" : "❌";
  const messege = result + " It Should be " + expectedValue + " and it is " + actualValue;
  console.log(messege);
}

function testFizzBuzz(a, e) {
  const actualValue = fizzBuzz(a);
  composeMessege(actualValue, e);
}

function testall() {
  testFizzBuzz(17, "17");
  testFizzBuzz(0, "fizzbuzz");
  testFizzBuzz(45, "fizzbuzz");
  testFizzBuzz(25, "buzz");
  testFizzBuzz(21, "fizz");
  testFizzBuzz(31, "31");
}

testall();