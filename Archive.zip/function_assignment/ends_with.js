/*
  Write a function that tells if a string ends with a specific substring

  Examples:
    endsWith('hello world', 'ld') => true
    endsWith('hello world', 'wor') => false
    endsWith('hello world', 'hello') => false

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function endsWith(string, substring) {
  // Implementation here.
  if (substring = ""){
    return false;
  }
  
  for (let digitFromLast = 1; digitFromLast <= substring.length; digitFromLast++) {
    if (string[string.length - digitFromLast] !== substring[substring.length - digitFromLast]) {
      return false;
    }
  }

  return true;
}

function composeMessege(actualValue, expectedValue) {
  const result = actualValue === expectedValue ? "✅": "❌";
  const messege = result + " It Should be " + expectedValue + " and it is " + actualValue;
  console.log(messege);
}

function testEndsWith(a, b, e) {
  const actualValue = endsWith (a, b);
  composeMessege(actualValue, e);
}

function testall(){
testEndsWith("a a x oma", " ma", false);
testEndsWith("aami je tomaar", " tomar", false);
testEndsWith("Lala gopgapangam das", "apangam das", true);
testEndsWith("Vande Matram.", "vande Matram", false);
}

testall();