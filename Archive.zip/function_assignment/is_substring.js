/*
  Implement the below function that tells if a string is substring of another string

  Usage:
    isSubstring('hello world', 'worl') => true
    isSubstring('repeating iiiiiiii', 'iii') => true
    isSubstring('not found', 'for') => false

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function isSubstringAt(string, subString, position) {
  for (let index = 0; index < subString.length; index++) {
    if (subString[index] !== string[position + index]) {
      return false;
    }
  }
  return true;
}


function isSubstring(string, subString) {
  // Implementation here.
  for (let index = 0; index < string.length; index++) {
    if (subString[0] === string[index] && isSubstringAt(string, subString, index)) {
      return true;
    }
  }
  return false;
}

function composeMessege(actualValue, expectedValue) {
  const result = actualValue === expectedValue ? "✅" : "❌";
  const messege = result + " It Should be " + expectedValue + " and it is " + actualValue;
  console.log(messege);
}

function testIsString(a, b, e) {
  const actualValue = isSubstring(a, b);
  composeMessege(actualValue, e);
}

function testall() {
  testIsString("Girdhari", "dhar", true);
  testIsString("Mohanlal", "halal", false);
  testIsString("Incase of emergency", "case o", true);
  testIsString("Fire Extinguishar", "", false);
  testIsString("Hello world", "lo", true);
  testIsString('hello world', 'worl', true);
  testIsString('repeating iiiiiiii', '', true);
  testIsString('not found', 'for', false);
}

testall();