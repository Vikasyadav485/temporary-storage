/*
  Implement the below function 
  that replaces a character `match` with another character `replacement`
  in a given text and returns a new string.

  Examples:
    replace('hello world', 'l', 'n') => 'henno world'
    replace('no spaces in here', ' ', '_') => 'no_spaces_in_here'
    replace('', 'd', 'e') => ''

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function replace(text, match, replacement) {
  // Implementation here.
  let newWord = "";
  for (let index = 0; index < text.length; index++) {
    newWord += text[index] === match ? replacement : text[index];
  }
  return newWord;
}

function composeMessege(actValue, expValue) {
  const result = actValue === expValue ? "✅" : "❌";
  let messege = result + " It Should be " + expValue;
  messege += " and it is " + actValue;
  console.log(messege);
}

function testStringReplace(a, b, c, e) {
  const actualValue = replace(a, b, c);
  composeMessege(actualValue, e);
}

function testall() {
  testStringReplace("sandip", "s", "m", "mandip");
  testStringReplace("Fire Exit", "E", "F", "Fire Fxit");
  testStringReplace("Table shop", "T", "C", "Cable shop");
  testStringReplace("Wonder", "o", "a", "Wander");
  testStringReplace("Sasaram", "a", "o", "Sosorom");
}

testall();