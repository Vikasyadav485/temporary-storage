function characterCount(a) {
  
}


function charcterTally(a) {

}