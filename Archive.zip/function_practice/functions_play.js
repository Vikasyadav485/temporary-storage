function sum(x, y) {
    return x + y;
}

function divide(x, y) {
    return x / y;
}

function multi(x, y) {
    return x * y;
}

function subtraction(x, y) {
    return x - y;
}

function square(x) {
    return x * x;
}

function modulo(x, y) {
    return x % y;
}

function min(x, y) {
    return (x < y) ? x : y;
}

function minOf3(x, y, z) {
    return min(min(x, y), z);
}

function secondGreatest(x, y, z) {
    return
}

function max(x, y) {
    return (x > y) ? x : y;
}

function maxOf3(x, y, z) {
    return max(max(x, y), z);
}

function print_table(x) {
    for (let multiple = 1; multiple <= 10; multiple++) {
        let term = multi(x, multiple);

        console.log(term);
    }
}

function termOfAP(x, y, z) {
    return x + y * (z - 1);
}

function sumOfAP(x, y, z) {
    let sum = 0;
    for (let term = 1; term <= z; term++) {
        sum = sum(sum, termOfAP(x, y, term));
    }
    return sum;
}

const a = 1;
const b = 1;
const c = 100;

console.log(termOfAP(a, b, c));
console.log(sumOfAP(a, b, c));
