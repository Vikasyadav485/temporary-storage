function check(a) {
  if (a === "a" || a === "e" || a === "i" || a === "o" || a === "u") {
    return true;
  }
  return false;
}

function alternateString(string) {
  let newString = "";
  while (string.length >= 1) {
    let newWord = string[0];
    let left = "";
    for (let index = 1; index < string.length; index++) {
      if (check(newWord[newWord.length - 1]) !== check(string[index])) {
        newWord += string[index];
      } else {
        left += string[index];
      }
    }
    newString += newWord + ',';
    string = left;
  }
  console.log(newString);
}

alternateString("ramnaerao");
alternateString("aadress");
alternateString("vishwakarma");
alternateString("sangramsingh");
alternateString("ramnaerao");
alternateString("aaabbb");
alternateString("aaaaabbbbb");
