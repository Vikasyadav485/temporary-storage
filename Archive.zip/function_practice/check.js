function sizeOfString(a) {
  return a.length;
}

function endsWith(string, substring) {
  // Implementation here.
  let isLastsWith = true;

  for (let digitFromLast = 1; digitFromLast <= sizeOfString(substring); digitFromLast++) {
    if (string[sizeOfString(string) - digitFromLast] !== substring[sizeOfString(substring) - digitFromLast]) {
      isLastsWith = false;
    }
  }

  return isLastsWith;
}

function composeMessege(actualValue, expectedValue) {
  const result = actualValue === expectedValue ? "✅": "❌";
  const messege = result + " It Should be " + expectedValue + " and it is " + actualValue;
  console.log(messege);
}

function testEndsWith(a, b, e) {
  const actualValue = endsWith (a, b);
  composeMessege(actualValue, e);
}

function testall(){
testEndsWith("a a x oma", "", false);
testEndsWith("aami je tomaar", " tomar", false);
testEndsWith("Lala gopgapangam das", "apangam das", true);
testEndsWith("Vande Matram.", "vande Matram", false);

}

testall();