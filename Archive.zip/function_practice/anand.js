function digitFind(a, b) {
  for (let index = a; index <= b; index++) {
    console.log(index);
  }
}

function find(a) {
  digitFind(0, a - 1);
  console.log('yay! ' + a);
  digitFind(a + 1, 10);
  console.log("\n")
}

function testFind(){
  find(0);
  find(6);
  find(3);
  find(1);
  find(4);
  find(7);
}
testFind();