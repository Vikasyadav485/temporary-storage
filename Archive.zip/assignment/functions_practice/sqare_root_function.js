function squareRoot(a) {
    return a ** 0.5;
}

function isApprox(a, b) {
    let c = a - b;
    c = (c > 0) ? c : c * (-1);
    return c < 0.05;
}

function composeMessege(actualNumber, expectedValue) {
    const result = isApprox(actualNumber, expectedValue) ? "✅" : "❌";
    const messege = result + " Square root should be " + expectedValue + " and it is " + actualNumber;

    console.log(messege);
}

function testSquareRoot(a, e) {
    const actualValue = squareRoot(a);
    composeMessege(actualValue, e);
}

testSquareRoot(4, 2);
testSquareRoot(2, 1.414);
testSquareRoot(3, 1.732);
testSquareRoot(99, 9.949);