function binary(a) {
    let decimalNumber = a;
    let binaryNumber = 0;
    let digit = 0;

    while (decimalNumber > 0) {
        let binaryBit = decimalNumber % 2;
        binaryNumber = binaryBit * (10 ** digit) + binaryNumber;
        decimalNumber = (decimalNumber - binaryBit) / 2;
        digit++;
    }
    return binaryNumber;
}

function composeMessege(actualNumber, expectedValue) {
    const result = (actualNumber === expectedValue) ? "✅" : "❌";
    const messege = result + " Binary number should be " + expectedValue + " and it is " + actualNumber;

    console.log(messege);
}

function testBinaryNumber(a, e) {
    const actualValue = binary(a);
    composeMessege(actualValue, e);
}

testBinaryNumber(3, 11);
testBinaryNumber(32, 100000);
testBinaryNumber(17, 10001);
testBinaryNumber(90, 1011010);