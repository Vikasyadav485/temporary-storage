function checkPrime(a) {
  let isPrime = false;

  isPrime = a > 1;

  for (let divisor = 2; divisor < a; divisor++) {
    if (a % divisor === 0) {
      isPrime = false;
    }
  }
  return isPrime;
}

function firstAbovePrime(a) {
  let firstPrime = a + 1;

  while (!checkPrime(firstPrime)) {
    firstPrime++;
  }

  return firstPrime;
}

function composeMessege(a, actualNumber, expectedValue) {
  const result = (actualNumber === expectedValue) ? "✅" : "❌";
  const messege = result + " First above prime of " + a + " should be " + expectedValue + " and it is " + actualNumber;

  console.log(messege);
}

function testFirstAbovePrime(a, e) {
  const actualValue = firstAbovePrime(a);
  composeMessege(a, actualValue, e);
}

function testall() {
testFirstAbovePrime(0, 2);
testFirstAbovePrime(101, 103);
testFirstAbovePrime(113, 127);
testFirstAbovePrime(31, 37);
}

testall();