function sumOfAP(a, d, n) {
  let term = a;
  let sumOfAP = 0;

  for (let count = 1; count <= n; count++) {
    sumOfAP = sumOfAP + term;
    term = term + d;
  }
  return sumOfAP;
}

function composeMessege(actualNumber, expectedValue) {
  const result = (actualNumber === expectedValue) ? "✅" : "❌";
  const messege = result + " Sum of AP should be " + expectedValue + " and it is " + actualNumber;

  console.log(messege);
}

function testSumOfAP(a, d, n, e) {
  const actualValue = sumOfAP(a, d, n);
  composeMessege(actualValue, e);
}

testSumOfAP(1, 1, 100, 5050);
testSumOfAP(1, 2, 50, 2500);
testSumOfAP(6, 3, 12, 270);
testSumOfAP(4, 2, 10, 130);