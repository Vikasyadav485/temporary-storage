function isPalindrome(a) {
  let numberString = "" + a;
  const noOfDigits = numberString.length;
  let palindrome = true;

  for (let digitCount = 1; digitCount <= noOfDigits; digitCount++) {
    if (numberString[noOfDigits - digitCount] !== numberString[digitCount - 1]) {
      palindrome = false;
    }
  }
  return palindrome;
}

function composeMessege(a, actualNumber, expectedValue) {
  const result = (actualNumber === expectedValue) ? "✅" : "❌";
  const messege = result + " Is " + a + " a palindrome?  Should be " + expectedValue + " and it is " + actualNumber;

  console.log(messege);
}

function testIsPalindrome(a, e) {
  const actualValue = isPalindrome(a);
  composeMessege(a, actualValue, e);
}

testIsPalindrome(1, true);
testIsPalindrome(44, true);
testIsPalindrome(1213, false);
testIsPalindrome(12321, true);
testIsPalindrome(1245531, false);