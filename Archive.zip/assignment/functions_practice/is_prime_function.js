function checkPrime(a) {
  let isPrime = false;

  isPrime = a > 1;

  for (let divisor = 2; divisor < a; divisor++) {
    if (a % divisor === 0) {
      isPrime = false;
    }
  }
  return isPrime;
}

function composeMessege(n, actualNumber, expectedValue) {
  const result = (actualNumber === expectedValue) ? "✅" : "❌";
  const messege = result + " is " + n + " prime ?  should be " + expectedValue + " and it is " + actualNumber;

  console.log(messege);
}

function testPrime(a, e) {
  const actualValue = checkPrime(a);
  composeMessege(a, actualValue, e);
}

testPrime(0, false);
testPrime(1, false);
testPrime(2, true);
testPrime(5, true);
testPrime(97, true);