function smallerNumber(a, b) {
  return (a < b) ? a : b;
}

function hcfOfTwoNumbers(a, b) {
  let hcf;
  for (let divisor = 1; divisor <= smallerNumber(a, b); divisor++) {
    if (b % divisor === 0 && a % divisor === 0) {
      hcf = divisor;
    }
  }
  return hcf;
}

function composeMessege(actualNumber, expectedValue) {
  const result = (actualNumber === expectedValue) ? "✅" : "❌";
  const messege = result + " hcf should be " + expectedValue + " and it is " + actualNumber;

  console.log(messege);
}

function testHcf(a, b, e) {
  const actualValue = hcfOfTwoNumbers(a, b);
  composeMessege(actualValue, e);
}

testHcf(1, 1, 1);
testHcf(4, 10, 2);
testHcf(143, 78, 13);
testHcf(1331, 44, 11);