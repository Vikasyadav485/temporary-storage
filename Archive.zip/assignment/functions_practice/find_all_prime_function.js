function checkPrime(a) {
  let isPrime = false;

  isPrime = a > 1;

  for (let divisor = 2; divisor < a; divisor++) {
    if (a % divisor === 0) {
      isPrime = false;
    }
  }
  return isPrime;
}

function primeBetweenRange(a, b) {
  let primeNumbers = "";
  for (let term = a; term <= b; term++) {
    primeNumbers = checkPrime(term) ? primeNumbers + term + " " : primeNumbers;
  }
  return primeNumbers;
}

function composeMessege(a, b, actualNumber, expectedValue) {
  const result = (actualNumber === expectedValue) ? "✅" : "❌";
  const messege = result + " Prime numbers between the range (" + a + "," + b + ") should be " + expectedValue + " and it is " + actualNumber;

  console.log(messege);
}

function testPrimeNumbersInRange(a, b, e) {
  const actualValue = primeBetweenRange(a, b);
  composeMessege(a, b, actualValue, e);
}

testPrimeNumbersInRange(0, 5, "2 3 5 ");
testPrimeNumbersInRange(1, 10, "2 3 5 7 ");
testPrimeNumbersInRange(10, 25, "11 13 17 19 23 ");
testPrimeNumbersInRange(25, 75, "29 31 37 41 43 47 53 59 61 67 71 73 ");
testPrimeNumbersInRange(100, 200, "101 103 107 109 113 127 131 137 139 149 151 157 163 167 173 179 181 191 193 197 199 ")