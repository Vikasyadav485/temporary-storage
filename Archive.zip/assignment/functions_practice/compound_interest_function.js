function compoundInterest(a, b, c) {
  let interest = 0;
  let principal = a;

  for (let year = 1; year <= c; year++) {
    interest = principal * b / 100;
    principal = principal + interest;
  }

  return principal - a;
}

function isApprox(a, b) {
  let c = a - b;
  c = (c > 0) ? c : c * (-1);
  return c < 0.05;
}

function composeMessege(actualNumber, expectedValue) {
  const result = isApprox(actualNumber, expectedValue) ? "✅" : "❌";
  const messege = result + " Compound interest should be " + expectedValue + " and it is " + actualNumber;
  console.log(messege);
}

function testCompoundInterest(a, b, c, e) {
  const actualValue = compoundInterest(a, b, c);
  composeMessege(actualValue, e);
}

function testall() {
  testCompoundInterest(1000, 4, 2, 81.6);
  testCompoundInterest(1250, 3, 6, 242.57);
  testCompoundInterest(936, 5, 8, 446.90);
  testCompoundInterest(17500, 6, 3, 3342.78);
  testCompoundInterest(8900, 7, 8, 6391.86);
}

testall();