function factorial(a) {
    let product = 1;
    for (let term = a; term > 0; term--) {
        product = product * term;
    }
    return product;
}

function composeMessege(actualNumber, expectedValue) {
    const result = (actualNumber === expectedValue) ? "✅" : "❌";
    const messege = result + " Factorial should be " + expectedValue + " and it is " + actualNumber;

    console.log(messege);
}

function testFactorial(a, e) {
    const actualValue = factorial(a);
    composeMessege(actualValue, e);
}

testFactorial(0, 1);
testFactorial(1, 1);
testFactorial(6, 720);
testFactorial(7, 5040);