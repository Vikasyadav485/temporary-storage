function evenNumbersInRange(a, b) {
  let evenNumbers = "";
  for (let term = a; term <= b; term++) {
    if (term % 2 === 0) {
      evenNumbers = evenNumbers + term + " ";
    }
  }
  return evenNumbers;
}

function composeMessege(actualNumber, expectedValue) {
  const result = (actualNumber === expectedValue) ? "✅" : "❌";
  const messege = result + " Even numbers should be " + expectedValue + " and these are " + actualNumber;

  console.log(messege);
}

function testEvenNumbers(a, b, e) {
  const actualValue = evenNumbersInRange(a, b);
  composeMessege(actualValue, e);
}

testEvenNumbers(0, 10, "0 2 4 6 8 10 ");
testEvenNumbers(5, 12, "6 8 10 12 ");
testEvenNumbers(79, 91, "80 82 84 86 88 90 ");
testEvenNumbers(33, 33, "");