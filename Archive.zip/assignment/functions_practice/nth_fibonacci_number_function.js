function nthTerm(n) {
  let lastTerm = 0;
  let previousTerm = 1;
  let currentTerm;

  for (let term = 1; term <= n; term++) {
    currentTerm = lastTerm;
    lastTerm = lastTerm + previousTerm;
    previousTerm = currentTerm;
  }
  return currentTerm;
}

function composeMessege(actualNumber, expectedValue) {
  const result = (actualNumber === expectedValue) ? "✅" : "❌";
  const messege = result + " nth fibonacci number should be " + expectedValue + " and it is " + actualNumber;

  console.log(messege);
}

function testnthTerm(n, e) {
  const actualValue = nthTerm(n);
  composeMessege(actualValue, e);
}

testnthTerm(1, 0);
testnthTerm(2, 1);
testnthTerm(3, 1);
testnthTerm(10, 34);
