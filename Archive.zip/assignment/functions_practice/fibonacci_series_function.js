function fibonacciSeries(n) {
  let lastTerm = 0;
  let previousTerm = 1;
  let currentTerm;
  let series = "";

  for (let term = 1; term <= n; term++) {
    currentTerm = lastTerm;
    lastTerm = lastTerm + previousTerm;
    previousTerm = currentTerm;
    series = series + currentTerm + " ";
  }
  return series;
}

function composeMessege(actualNumber, expectedValue) {
  const result = (actualNumber === expectedValue) ? "✅" : "❌";
  const messege = result + " Fibonacci series should be " + expectedValue + " and it is " + actualNumber;

  console.log(messege);
}

function testFibonacciSeries(n, e) {
  const actualValue = fibonacciSeries(n);
  composeMessege(actualValue, e);
}

testFibonacciSeries(1, "0 ");
testFibonacciSeries(2, "0 1 ");
testFibonacciSeries(4, "0 1 1 2 ");
testFibonacciSeries(7, "0 1 1 2 3 5 8 ")