function noOfDigits(a) {
  const numberString = "" + a;
  return numberString.length;
}

function sumOfPowerOfDigits(a) {
  let candidateNumber = a;
  let sum = 0;
  const totalDigits = noOfDigits(a);

  for (let digitCount = 1; digitCount <= totalDigits; digitCount++) {
    let digit = candidateNumber % 10;
    sum = sum + (digit ** totalDigits);
    candidateNumber = (candidateNumber - digit) / 10;
  }
  return sum;
}

function isArmstrong(a) {
  return sumOfPowerOfDigits(a) === a;
}

function composeMessege(a, actualNumber, expectedValue) {
  const result = (actualNumber === expectedValue) ? "✅" : "❌";
  const messege = result + " Is " + a + " an armstrong number should be " + expectedValue + " and it is " + actualNumber;

  console.log(messege);
}

function testIsArmstrong(a, e) {
  const actualValue = isArmstrong(a);
  composeMessege(a, actualValue, e);
}

testIsArmstrong(2, true);
testIsArmstrong(153, true);
testIsArmstrong(541, false);
testIsArmstrong(1634, true);
testIsArmstrong(7245, false)