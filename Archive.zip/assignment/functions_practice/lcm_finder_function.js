function greaterNumber(a, b) {
  return (a > b) ? a : b;
}

function lcmOfTwoNumbers(a, b) {
  let loop = true;
  let term = greaterNumber(a, b);
  let lcm;

  while (loop) {
    if (term % a === 0 && term % b === 0) {
      lcm = term;
      loop = false;
    }
    term++;
  }
  return lcm;
}

function composeMessege(actualNumber, expectedValue) {
  const result = (actualNumber === expectedValue) ? "✅" : "❌";
  const messege = result + " LCM should be " + expectedValue + " and it is " + actualNumber;

  console.log(messege);
}

function testLcm(a, b, e) {
  const actualValue = lcmOfTwoNumbers(a, b);
  composeMessege(actualValue, e);
}

testLcm(1, 1, 1);
testLcm(24, 216, 216);
testLcm(26, 117, 234);
testLcm(63, 112, 1008);