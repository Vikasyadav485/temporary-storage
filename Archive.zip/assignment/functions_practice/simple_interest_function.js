function simpleInterest(a, b, c) {
    return (a * b * c) / 100;
}

function composeMessege(actualNumber, expectedValue) {
    const result = (actualNumber === expectedValue) ? "✅" : "❌";
    const messege = result + " Simple interest should be " + expectedValue + " and it is " + actualNumber;

    console.log(messege);
}

function testSimpleInterest(a, b, c, e) {
    const actualValue = simpleInterest(a, b, c);
    composeMessege(actualValue, e);
}

function testall() {
    testSimpleInterest(100, 5, 2, 10);
    testSimpleInterest(1000, 4, 6, 240);
    testSimpleInterest(12, 4, 3, 1.44);
    testSimpleInterest(45, 4, 3, 5.4);
}

testall();