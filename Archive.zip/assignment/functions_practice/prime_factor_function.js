function primeFactors(a) {
  let givenNumber = a;
  let factors = "";

  for (let divisor = 2; divisor <= givenNumber; divisor++) {
    if (givenNumber % divisor === 0) {
      givenNumber = givenNumber / divisor;
      factors = factors + divisor + " ";
      divisor = 1;
    }
  }
  return factors;
}

function composeMessege(actualNumber, expectedValue) {
  const result = (actualNumber === expectedValue) ? "✅" : "❌";
  const messege = result + " Prime factors should be " + expectedValue + " and it is " + actualNumber;

  console.log(messege);
}

function testPrimeFactors(a, e) {
  const actualValue = primeFactors(a);
  composeMessege(actualValue, e);
}

testPrimeFactors(2, "2 ");
testPrimeFactors(12, "2 2 3 ");
testPrimeFactors(56, "2 2 2 7 ");
testPrimeFactors(81, "3 3 3 3 ");
testPrimeFactors(576, "2 2 2 2 2 2 3 3 ");