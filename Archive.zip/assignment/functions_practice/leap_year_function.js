function isCenturyYear(a) {
  return a % 100 === 0;
}

function isLeapYear(a) {
  return isCenturyYear(a) ? a % 400 === 0 : a % 4 === 0;
}

function composeMessege(a, actualNumber, expectedValue) {
  const result = (actualNumber === expectedValue) ? "✅" : "❌";
  const messege = result + " Is " + a + " a leap year?  Should be " + expectedValue + " and it is " + actualNumber;

  console.log(messege);
}

function testLeapYear(a, e) {
  const actualValue = isLeapYear(a);
  composeMessege(a, actualValue, e);
}

testLeapYear(1800, false);
testLeapYear(1880, true);
testLeapYear(1996, true);
testLeapYear(2000, true);
testLeapYear(2100, false);