// Do not rename a, use it as input for your program.
// While testing we will change its values.

const a = 77;

// Print the square root of a
// Printing more than one output or printing anything other than square root might will be consider as error.
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

let decimalNumber = a;
let root = 0;

while ((root * root) <= decimalNumber) {
    root++;
}

root--;

if ((root * root) === decimalNumber) {
    console.log(root);
} else {
    let multiple = root ** 2;
    let divisor = root * 2;
    decimalNumber = (decimalNumber - multiple) * 100;

    for (let term = 1; term <= 15; term++) {
        let rootAfterDecimal = 1;

        while ((divisor * 10 + rootAfterDecimal) * rootAfterDecimal < decimalNumber) {
            rootAfterDecimal++;
        }

        rootAfterDecimal = rootAfterDecimal - 1;
        root = root + rootAfterDecimal / (10 ** term);
        console.log(root);
        multiple = (divisor * 10 + rootAfterDecimal) * rootAfterDecimal;
        decimalNumber = (decimalNumber - multiple) * 100;
        divisor = divisor * 10 + 2 * rootAfterDecimal;
    }
    console.log(root);
}