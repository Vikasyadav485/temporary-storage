// Do not rename startOfRange or endOfRange, use them as input for your program.
// While testing we will change their values.

const startOfRange = 0;
const endOfRange = 100;

// Print all prime numbers between startOfRange and endOfRange(both inclusive).
// For example, if startOfRange = 5 and endOfRange = 13, then the output should be
// 5
// 7
// 11
// 13
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

for (let term = startOfRange; term <= endOfRange; term++) {
  let prime = true;

  for (let divisor = 2; divisor < term; divisor++) {
    if (term % divisor === 0) {
      prime = false;
    }
  }

  if (term === 1 || term === 0) {
    prime = false;
  }

  if (prime) {
    console.log(term);
  }
}