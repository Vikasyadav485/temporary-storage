// Do not rename a, use it as input for your program.
// While testing we will change its values.

const a = 15625;

// Print the prime factors of a
// For example, if a = 12, then the output should be
// 2
// 2
// 3
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

let candidateNumber = a;

for (let divisor = 2; divisor <= candidateNumber; divisor++) {
  if (candidateNumber % divisor === 0) {
    console.log(divisor);
    candidateNumber = candidateNumber / divisor;
    divisor = 1;
  }
}