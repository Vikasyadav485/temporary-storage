// Do not rename p, t or r, use them as input for your program.
// While testing we will change their values.

const p = 100;
const t = 1;
const r = 2;
// Print the simple interest.
// Printing more than one output or printing anything other than simple interest might will be consider as error.
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

const simpleInterest = (p * r * t) / 100;

console.log(simpleInterest);