// Do not rename a, use it as input for your program.
// While testing we will change their values.
// n will be a natural number including 0.

const a = 65;

// Print the binary representation of a
// If a = 12, then the output should be
// 0
// 0
// 1
// 1

// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

let decimalNumber = a;

while (decimalNumber > 0) {
  let binaryBit = decimalNumber % 2;
  console.log(binaryBit);
  decimalNumber = (decimalNumber - binaryBit) / 2;
}

if (a === 0) {
  console.log(a);
}