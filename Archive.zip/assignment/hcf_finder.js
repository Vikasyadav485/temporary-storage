// Do not rename a or b, use them as input for your program.
// While testing we will change their values.

const a = 0;
const b = 1;

// Print the HCF of a and b
// Printing more than one output or printing anything other than HCF might will be consider as error.

// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

let hcf = 0;

for (let divisor = 1; divisor <= b; divisor++) {
  if (b % divisor === 0 && a % divisor === 0) {
    hcf = divisor;
  }
}

hcf = (a === 0) ? 0 : hcf;

console.log(hcf);