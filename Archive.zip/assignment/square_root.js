// Do not rename a, use it as input for your program.
// While testing we will change its values.

const a = 576;

// Print the square root of a
// Printing more than one output or printing anything other than square root might will be consider as error.
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

const squareRoot = a ** 0.5;

console.log(squareRoot);