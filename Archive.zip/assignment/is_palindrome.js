// Do not rename a, use them as input for your program.
// While testing we will change its values.

const a = 11;

// Print true if a is palindrome otherwise print false
// Printing more than one output or printing anything other than palindrome or not palindrome might will be consider as error.
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

let numberString = "" + a;
const noOfDigits = numberString.length;
let isPalindrome = true;

for (let digitCount = 1; digitCount <= noOfDigits; digitCount++) {
  if (numberString[noOfDigits - digitCount] !== numberString[digitCount - 1]) {
    isPalindrome = false;
  }
}

console.log(isPalindrome);