// Do not rename a, use it as input for your program.
// While testing we will change its values.

const a = 476;

// Print the square root of a
// Printing more than one output or printing anything other than square root might will be consider as error.
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

// const squareRoot = a ** 0.5;
// console.log(squareRoot);

let num = a;
let root = 0;
let rootAfterDecimal = 1;

while ((root * root) < num) {
    root++;
    // console.log(root);
}
root --;
if ((root * root) === num) {
    console.log(root);
} else {
    // for (let count = 1; count <= 2; count++) {
        num = (num - root * root) * 100;
        let auxroot = root + root;
        while ((auxroot * 10 + rootAfterDecimal) * rootAfterDecimal < num){
            rootAfterDecimal++;
        }
        rootAfterDecimal = rootAfterDecimal - 1;
        root = root + rootAfterDecimal / 10;
    // }
    console.log(root);
}









// let num = a;
// let root = 0;
// let sqrroot = 1;

while ((root * root) < num) {
    root++;
}
root --;
if ((root * root) === num) {
    console.log(root);
} else {
    rootAfterDecimal = root;
    let auxNumber = rootAfterDecimal ** 2;
    let auxroot = rootAfterDecimal * 2;
    num = (num - auxNumber) * 100;
    for (let count = 1; count <= 2; count++) {
        while ((auxroot * 10 + rootAfterDecimal) * rootAfterDecimal < num){
            rootAfterDecimal++;
        }
        rootAfterDecimal = rootAfterDecimal - 1;
        root = root + rootAfterDecimal / (10 ** count);
        console.log(root);
        auxNumber = (auxroot * 10 + rootAfterDecimal) * rootAfterDecimal; 
        num = (num - auxNumber) * 100;
        auxroot = auxroot * (10 ** count) + 2 * rootAfterDecimal;
    }
    console.log(root);
}









// let num = a;
// let root = 0;
// let sqrroot = 1;

while ((root * root) < num) {
    root++;
}

root --;

if ((root * root) === num) {
    console.log(root);
} else {
    // sqrroot = root;
    let auxNumber = rootAfterDecimal ** 2;
    let auxroot = rootAfterDecimal * 2;
    num = (num - auxNumber) * 100;

    for (let count = 1; count <= 8; count++) {
        rootAfterDecimal = 1;
        while ((auxroot * 10 + rootAfterDecimal) * rootAfterDecimal < num){
            rootAfterDecimal++;
        }
        rootAfterDecimal = rootAfterDecimal - 1;
        root = root + rootAfterDecimal / (10 ** count);
        console.log(root);
        auxNumber = (auxroot * 10 + rootAfterDecimal) * rootAfterDecimal; 
        num = (num - auxNumber) * 100;
        auxroot = auxroot * 10 + 2 * rootAfterDecimal;
    }
    console.log(root);
}