function changeDir(){
  
}

while(true){
  const command = prompt("> ");
  const tokens = command.split(' ');
  switch(){
    case "cd": 
    
  }
}