// function triangularNumber(n) {
//   if (n === 1) {
//     return 1;
//   }
//   return n + triangularNumber(n - 1);
// }

// function noOfFactors(a, index) { 
//   if (index * index >= a) {
//     return 1;
//   }
//   if (a % index === 0) {
//     return 1 + noOfFactors(a, index + 1);
//   }

//   return noOfFactors(a, index + 1);
// }

// function termCount(a) {
//   let index = 1;
//   let count = 0;
//   while (count <= a) {
//     count = noOfFactors(triangularNumber(index), 1);
//     if (count >= a) {
//       return triangularNumber(index);
//     }
//     index++;
//   }
// }


function triangularNumber(n) {
  let sum = 0;
  for (let index = 1; index <= n; index++) {
    sum += index;
  }
  return sum;
}

function noOfFactors(a) {
  let count = 0;
  for (let index = 1; index * index <= a; index++) {
    if (a % index === 0) {
      count++;
    }
  }
  return count * 2;
}

function termCount(a) {
  let index = 1;
  let count = 0;
  while (count <= a) {
    count = noOfFactors(triangularNumber(index));
    if (count >= a) {
      return triangularNumber(index);
    }
    index++;
  }
}


console.log(termCount(500));
