function sumOfEven(n) {
  if (n === 0) {
    return 0;
  }
  if (n % 2 === 0) {
    return fibonacciNth(n) + sumOfEven(n - 2);
  }
  return sumOfEven(n - 1);
}

function fibonacciNth(n) {
  if (n === 1) {
    return 0;
  }
  if (n === 2) {
    return 1;
  }
  return fibonacciNth(n - 1) + fibonacciNth(n - 2);
}

console.log(sumOfEven(5));