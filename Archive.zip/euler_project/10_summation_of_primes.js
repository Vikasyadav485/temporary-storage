function isPrime(a) {
  const b = a >= 2;
  for(let index = 2; index * index <= a; index++) {
    if (a % index === 0) {
      return false;
    }
  }
  return b;
}

function sumOfPrimesTill(s, e) {
  let sum = 0;
  for (let index = s; index <= e; index ++) {
    if(isPrime(index)) {
      sum += index;
    }
  }
  return sum;
}

console.log(sumOfPrimesTill(0, 2000000));