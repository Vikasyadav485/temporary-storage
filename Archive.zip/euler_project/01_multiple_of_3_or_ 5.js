function sumOfMultipleOf3or5(number) {
  const a = number - 1;
  if (number === 2) {
    return 0;
  }
  if (a % 3 === 0 || a % 5 === 0) {
    return a + sumOfMultipleOf3or5(number - 1);
  }
  return sumOfMultipleOf3or5(number - 1);
}

console.log(sumOfMultipleOf3or5(100));