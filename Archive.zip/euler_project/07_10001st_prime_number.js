function isPrime(candidate) {
  if(candidate < 2) {
    return false;
  }
  for (let index = 2; index * index <= candidate; index ++) {
    if(candidate % index === 0) {
      return false;
    }
  }
  return true;
}

function nthPrime(n) {
  let count = 0;
  let index = 1;
  while(count < n) {
    index++;
    if(isPrime(index)) {
      count ++;
    }
  }
  return index;
}

console.log(nthPrime(10001));