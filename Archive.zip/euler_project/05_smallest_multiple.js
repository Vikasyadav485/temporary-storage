function checkSmaller(a, b) {
  return a < b ? a : b;
}

function hcf(a, b) {
  for (let index = checkSmaller(a, b); index >= 1; index--) {
    if (a % index === 0 && b % index === 0) {
      return index;
    }
  }
}

function multiple(a, b) {
  let smallestMultiple = a;
  for (let index = a + 1; index <= b; index++) {
    smallestMultiple *= index / hcf(smallestMultiple, index);
  }
  return smallestMultiple;
}

// console.log(checkSmaller(108,56));
// console.log(hcf(57, 133));
console.log(multiple(1,20));