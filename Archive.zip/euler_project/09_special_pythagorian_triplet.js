function findPythagorianTriplet(a) {
  for (let n = 1; n < a; n++) {
    for (let m = 1; m < a; m++) {
      const a = m * m - n * n;
      const b = 2 * m * n;
      const c = m * m + n * n;
      if (a + b + c === 1000) {
        console.log(a, b, c);
      }
    }
  }
}

findPythagorianTriplet(21);