function isPalindrome(a, index) {
  const candidate = "" + a;
  if (index === isPalindrome.length) {
    return true;
  }
  if (candidate[index] !== candidate[candidate.length - 1 - index]) {
    return false;
  }
  return isPalindrome(a, index + 1);
}

function multipliedPalindrome(palindromeNumLimit, divisorNumLimit) {
  for (let palindromeCandidate = palindromeNumLimit; palindromeCandidate > 0; palindromeCandidate--) {
    if (isPalindrome(palindromeCandidate, 0)) {
      for (let divisorNum = divisorNumLimit; palindromeCandidate / divisorNum <= divisorNumLimit; divisorNum--) {
        if (palindromeCandidate % divisorNum === 0) {
          return palindromeCandidate;
        }
      }
    }
  }
}

function largestPalindromeProduct(multipleDigits) {
  const palindromeNumLimit = 100 ** multipleDigits - 1;
  const divisorNumLimit = 10 ** multipleDigits - 1;

  return multipliedPalindrome(palindromeNumLimit, divisorNumLimit);
}


// LIMITED TILL FOUR DIGITS : -
console.log(largestPalindromeProduct(1));
console.log(largestPalindromeProduct(2));
console.log(largestPalindromeProduct(3));
console.log(largestPalindromeProduct(4));