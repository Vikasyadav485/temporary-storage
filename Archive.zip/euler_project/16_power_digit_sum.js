function findPower(number, power) {
  if (power === 0) {
    return 1;
  }
  return number * findPower(number, power - 1);
}

function sumOfDigits(number) {
  if (number === 0) {
    return 0;
  }
  return number % 10 + sumOfDigits(Math.floor(number / 10));
}

function powerDigitSum(number, power) {
  return sumOfDigits(findPower(number, power));
}


console.log(powerDigitSum(2, 100));

// console.log(findPower(2, 10));

// console.log(sumOfDigits(485));