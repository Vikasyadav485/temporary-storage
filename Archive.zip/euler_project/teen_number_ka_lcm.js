function checkSmaller(a, b) {
  return a < b ? a : b;
}

function hcf(a, b) {
  for (let index = checkSmaller(a, b); index >= 1; index--) {
    if (a % index === 0 && b % index === 0) {
      return index;
    }
  }
}

function lcm(a, b, c) {
  const lcm1 = a * b / hcf(a, b);
  const lcm2 = lcm1 * c / hcf (c, lcm1);
  return lcm2;
}

console.log(lcm(2,4,6));