function sumOfSquare(f, n) {
  if(n === 0) {
    return 0;
  }
  return f * f + sumOfSquare(f + 1, n - 1);
}

function sumOfRange(f, n) {
  if (n === 0) {
    return 0;
  }
  return f + sumOfRange(f + 1, n - 1);
}

function sumSquareDifference(f, n) {
  const sumOfSquares = sumOfSquare(f, n);
  const squareOfSum = sumOfRange(f, n) ** 2;
  return squareOfSum - sumOfSquares;
}

console.log(sumOfSquare(1, 100));
console.log(sumOfRange(1, 100) ** 2);
console.log(sumSquareDifference(1, 100));