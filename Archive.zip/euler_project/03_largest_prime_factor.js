function isPrime(a) {
  if (a === 2) {
    return true;
  }
  for (let index = 2; index * index < a; index++) {
    if (a % index === 0) {
      return false;
    }
  }
  return true;
}

function findLargestPrimeFactors(n) {
  let largestPrimeFactor = 0;
  for (let index = 2; index <= n; index++) {
    if (isPrime(index, 2) && n % index === 0) {
      n = n / index;
      largestPrimeFactor = index;
    }
  }
  return largestPrimeFactor;
}

console.log(findLargestPrimeFactors(600851475143));
console.log(findLargestPrimeFactors(14));




// USING RECURSION;

// function isPrime(a, index) {
//   if (a === 2 || index * index > a) {
//     return true;
//   }
//   if (a % index === 0 || a < 2) {
//     return false;
//   }
//   return isPrime(a, index + 1);
// }

// function primeFactors(n, index) {
//   if (index === n) {
//     return n;
//   }
//   if (n % index === 0 && isPrime(index, 2)) {
//     return primeFactors(n / index, 2);
//   }
//   return primeFactors(n, index + 1);
// }

// function largestPrimeFactor(n) {
//   return primeFactors(n, 2);
// }


// console.log(largestPrimeFactor(600851475143));
//  console.log(largestPrimeFactor(13195));