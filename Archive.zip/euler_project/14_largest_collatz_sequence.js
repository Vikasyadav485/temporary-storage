/* USE IF WANT TO PRINT THE SEQUENCE ALSO :-
function printCollatzSequence(a) {
  if (a === 1) {
    return 1;
  }
  console.log(a);

  const nextNum = a % 2 === 0 ? a / 2 : 3 * a + 1;

  return printCollatzSequence(nextNum);
}*/

function countCollatzSequenceTerms(a) {
  if (a === 1) {
    return 1;
  }
  const nextNum = a % 2 === 0 ? a / 2 : 3 * a + 1;

  return 1 + countCollatzSequenceTerms(nextNum);
}

function largestCollatzSequenceTill(a) {
  let previousTotalSequenceTerms = 0;
  let largestCollatzSequenceNumber = 1;

  for (let index = 1; index <= a; index++) {
    const totalSequenceTerms = countCollatzSequenceTerms(index);

    if (totalSequenceTerms > previousTotalSequenceTerms) {
      largestCollatzSequenceNumber = index;
      previousTotalSequenceTerms = totalSequenceTerms;
    }
  }
  return largestCollatzSequenceNumber;
}


console.log(largestCollatzSequenceTill(10000));

// console.log(countCollatzSequenceTerms(837799), "\n");

// console.log(printCollatzSequence(871));


// function composeMessage(ac)