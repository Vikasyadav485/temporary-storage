function checkPrime(primeCandidate, divisor) {
  if (divisor === 1) {
    return true;
  }
  if (primeCandidate % divisor === 0) {
    return false;
  }

  return checkPrime(primeCandidate, divisor - 1);
}

function isPrime(primeCandidate) {
  if (primeCandidate < 2) {
    return false;
  }

  return checkPrime(primeCandidate, primeCandidate - 1);
}

function composeMessage(discription, primeCandidate, actual, expected) {
  const rightMessage = `✅ ${discription} ${primeCandidate}`;
  const wrongMessage = `❌ ${discription} \n \n input : [${primeCandidate}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? rightMessage : wrongMessage;

  return message;
}

function testIsPrime(discription, primeCandidate, expected) {
  const actual = isPrime(primeCandidate);
  const message = composeMessage(discription, primeCandidate, actual, expected);
  
  console.log(message);
}

function testall() {
  testIsPrime("should be prime", 2, true);
  testIsPrime("should be prime", 3, true);
  testIsPrime("should not be prime", 1, false);
  testIsPrime("should not be prime", 0, false);
  testIsPrime("should be prime", 122, false);
  testIsPrime("should be prime", 1331, false);
  testIsPrime("should be prime", 67, true);
}

testall();