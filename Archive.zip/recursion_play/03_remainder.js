function remainder(dividend, divisor) {
  if (dividend < divisor) {
    return dividend;
  }
  return remainder(dividend - divisor, divisor);
}

function composeMessage(discription, dividend, divisor, actual, expected) {
  const rightMessage = `✅ ${discription}`;
  const wrongMessage = `❌ ${discription} \n
   input : [ ${dividend}, ${divisor}]\n   actual : ${actual}
   expected : ${expected} \n - - - -`;

  const message = actual === expected ? rightMessage : wrongMessage;

  return message;
}

function testRemainder(discription, dividend, divisor, expected) {
  const actual = remainder(dividend, divisor);
  const message = composeMessage(discription, dividend, divisor, actual, expected);
  console.log(message);
}

function testall() {
  testRemainder("divident is not fully divisible", 5, 2, 1);
  testRemainder("divident is fully divisible", 10, 2, 0);
  testRemainder("divident is 0 and divisor is non Zero", 0, 2, 0);
  testRemainder("divident is smaller than divisor", 15, 30, 15);
}

testall();