function termOfGP(a, r, n) {
  if (n === 1) {
    return a;
  }
  return termOfGP(a * r, r, n - 1);
}

console.log(termOfGP(2, 2, 4));