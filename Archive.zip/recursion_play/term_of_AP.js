function termOfAP(a, d, n) {
  if(n === 1) {
    return a;
  }
  return termOfAP(a + d, d, n - 1 );
}

console.log(termOfAP(1, 1, 12));
console.log(termOfAP(2, 3, 7));