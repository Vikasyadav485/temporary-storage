function sumOfAP(a, d, n) {
  if (n === 0) {
    return 0;
  }
  return a + sumOfAP(a + d, d, n - 1);
}

function composeMessage(discription, a, d, n, actual, expected) {
  const rightMessage = `✅ ${discription}`;
  const wrongMessage = `❌ ${discription} \n \n input : [${a}, ${d}, ${n}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? rightMessage : wrongMessage;

  return message;
}

function testSumOfAP(discription, a, d, n, expected) {
  const actual = sumOfAP(a, d, n);
  const message = composeMessage(discription, a, d, n, actual, expected);

  console.log(message);
}

function testall() {
  testSumOfAP("first term and difference both are positive", 2, 3, 10, 155);
  testSumOfAP("first term is positive and difference is negetive", 2, -3, 10, -115);
  testSumOfAP("first term and difference both are negative", -2, -3, 10, -155);
  testSumOfAP("first term is negative and difference is positive", -2, 3, 10, 115);
  testSumOfAP("first term and difference both are positive", 1, 2, 15, 225);
}

testall();