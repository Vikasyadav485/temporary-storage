function checkPalindrome(string, index) {
  if (index === string.length) {
    return true;
  }
  if (string[index] !== string[string.length - index - 1]) {
    return false;
  }

  return checkPalindrome(string, index + 1);
}

function isPalindrome(palindromeCandidate) {
  const string = palindromeCandidate + "";

  return checkPalindrome(string, 0);
}

function composeMessage(discription, palindromeCandidate, actual, expected) {
  const rightMessage = `✅ ${discription}`;
  const wrongMessage = `❌ ${discription} \n \n input : [${palindromeCandidate}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? rightMessage : wrongMessage;

  return message;
}

function testIsPalindrome(discription, palindromeCandidate, expected) {
  const actual = isPalindrome(palindromeCandidate);
  const message = composeMessage(discription, palindromeCandidate, actual, expected);

  console.log(message);
}

function testall() {
  testIsPalindrome("Given input is a number", 121, true);
  testIsPalindrome("Number with odd no. of digits", 1234321, true);
  testIsPalindrome("Number with even no. of digits", 123321, true);
  testIsPalindrome("Given input is a string", "abcdcba", true);
  testIsPalindrome("string with odd no. of characters", "mnoponm", true);
  testIsPalindrome("string with even no. of characters", "mnopponm", true);
  testIsPalindrome("Given number's all digits are same", 222, true);
  testIsPalindrome("Given string's all characters are same", "aaaaaa", true);
  testIsPalindrome("single character string", "a", true);
  testIsPalindrome("single digit number", 5, true);
  testIsPalindrome("empty string", "", true);

}

testall();