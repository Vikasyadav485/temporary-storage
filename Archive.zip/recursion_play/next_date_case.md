| Description | Input | Output |
| --- | --- | --- |
| Simple increment of a normal day | 15-03-2021 | 16-03-2021 |
| Year is being changed | 31-12-2021 | 01-01-2022 |
| Month of only 30 days | 31-04-2021 | "Invalid Date" |
| Month of only 30 days being changed | 30-03-2023 | 01-04-2023 |
| Month of 31 days being changed | 30-07-2024 | 31-07-2024 |
| It is not a leap year | 29-02-2021 | "Invalid Date" |
| It is a leap year | 28-02-2024 | 29-02-2024 |
| It is not only a century year but also a leap year | 28-02-2000 | 29-02-2000 |
| It is only a century year not a leap year | 28-02-1900 | 01-03-1900 |
| Date can be minimum 01 | 00-03-2021 | "Invalid Date" |
| Date can be maximum 31 | 32-03-2021 | "Invalid Date" |
| February couldn't have more than 29 days | 30-02-2021 | "Invalid Date" |
| There are not months less than 01 | 24-00-1998 | "Invalid Date" |
| There are not months more than 12 | 24-13-1998 | "Invalid Date" |
| Year cannot be zero | 23-02-0000 | "Invalid Date" |