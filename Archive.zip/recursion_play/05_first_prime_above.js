function checkPrime(primeCandidate, divisor) {
  if (divisor === 1) {
    return true;
  }
  if (primeCandidate % divisor === 0) {
    return false;
  }

  return checkPrime(primeCandidate, divisor - 1);
}

function firstPrimeAbove(number) {
  if (checkPrime(number + 1, number)) {
    return number + 1;
  }

  return firstPrimeAbove(number + 1);
}

function composeMessage(discription, number, actual, expected) {
  const rightMessage = `✅ ${discription}`;
  const wrongMessage = `❌ ${discription} \n \n input : [${number}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? rightMessage : wrongMessage;

  return message;
}

function testFirstPrimeAbove(discription, number, expected) {
  const actual = firstPrimeAbove(number);
  const message = composeMessage(discription, number, actual, expected);
  console.log(message);
}

function testall() {
  testFirstPrimeAbove("given number is prime", 3, 5);
  testFirstPrimeAbove("given number is prime", 31, 37);
  testFirstPrimeAbove("given number is composite", 44, 47);
  testFirstPrimeAbove("given number is 0 ", 0, 2);
  testFirstPrimeAbove("given number is 1", 1, 2);
  testFirstPrimeAbove("given number is 2", 2, 3);
  testFirstPrimeAbove("given number is prime", 103, 107);
}

testall();