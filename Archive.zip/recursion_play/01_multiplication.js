function multiply(multiplier, multiplicand) {
  if (multiplier === 0) {
    return 0;
  }
  return multiplicand + multiply(multiplier - 1, multiplicand);
}

function composeMessage(actual, expected) {
  const result = actual === expected ? "✅" : "❌";
  const message = `${result} | actual : ${actual} | expected : ${expected} |`;
  return message;
}

function checkMultiply(multiplier, multiplicand, expected) {
  const actual = multiply(multiplier, multiplicand);
  const message = composeMessage(actual, expected);
  console.log(message);
}

function testall() {
  checkMultiply(2, 3, 6);
  checkMultiply(18, 5, 90);
  checkMultiply(16, 7, 112);
  checkMultiply(0, 3, 0);
  checkMultiply(19, 7, 133);
  checkMultiply(12, 24, 288);
  checkMultiply(12, 24, 288);

}

testall();