function fibonacciNth(currentTerm, lastTerm, n) {
  if (n === 1) {
    return currentTerm;
  }
  return fibonacciNth(currentTerm + lastTerm, currentTerm, n - 1);
}

function nthFibonacciTerm(n) {
  if (n < 1) {
    return "invalid term";
  }
  return fibonacciNth(0, 1, n);
}

function composeMessage(discription, n, actual, expected) {
  const rightMessage = `✅ ${discription}`;
  const wrongMessage = `❌ ${discription} \n \n input : [${n}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? rightMessage : wrongMessage;

  return message;
}

function testFibonacci(discription, n, expected) {
  const actual = nthFibonacciTerm(n);
  const message = composeMessage(discription, n, actual, expected);

  console.log(message);
}


function testall() {
  testFibonacci("For term less than 1", 0, "invalid term");
  testFibonacci("For term less than 1", -1, "invalid term");
  testFibonacci("Normal positive term", 5, 3);
  testFibonacci("Normal positive term", 1, 0);
  testFibonacci("Normal positive term", 2, 1);
  testFibonacci("Normal positive term", 3, 1);
  testFibonacci("Normal positive term", 4, 2);
  testFibonacci("Normal positive term", 15, 377);
}

testall();