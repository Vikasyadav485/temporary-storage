function likeIdentity(x) {
  if (x === 0) {
    return 0;
  }
  return 1 + likeIdentity(x - 1);
}

console.log(likeIdentity(3));
console.log(likeIdentity(4));
console.log(likeIdentity(10));