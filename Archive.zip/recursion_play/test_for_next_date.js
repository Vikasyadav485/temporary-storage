
/**
 * Implement the `nextDate` function below. Given a date in the format dd-mm-yyyy, 
 * it should return the next date in the same format.
 * 
 * The input date will always follow the dd-mm-yyyy format. 
 * This means the first two characters will be digits for the day (e.g., 01, 23),
 *  
 * followed by a hyphen (-), the next two characters will be digits for the month (e.g., 01, 12), 
 * followed by another hyphen, and the remaining four characters will be digits for the year 
 * (any year between 0000 and 9999).
 * 
 * In case of an invalid date (with correct format dd-mm-yyyy), for example, "32-02-2025", 
 * return "Invalid Date".
 */

function isLeapYear(year) {
  if (year === 0) {
    return false;
  }
  if (year % 400 === 0 || year % 100 !== 0 && year % 4 === 0) {
    return true;
  }

  return false;
}

function isDateInvalid(day, month, year) {
  if (month < 1 || month > 12) {
    return true;
  }
  if (day < 1 || day > daysInThisMonth(month, year)) {
    return true;
  }

  return false;
}

function daysInThisMonth(month, year) {
  if (month === 2) {
    return isLeapYear(year) ? 29 : 28;
  }

  // switch (month) {
  //   case 4:
  //   case 6:
  //   case 9:
  //   case 11:
  //     return 30;
  //   default:
  //     return 31;
  // }

  return ((month - 1) % 7) % 2 === 0 ? 31 : 30;
}

function isLastDateOfMonth(date, month, year) {
  return date === daysInThisMonth(month, year);
}

function isLastDateOfYear(date, month) {
  return date === 31 && month === 12;
}

function paddedText(text, length) {
  return text.padStart(length, "0");
}

function formateDate(d, m, y) {
  const date = paddedText('' + d, 2);
  const month = paddedText('' + m, 2);
  const year = paddedText('' + y, 4);

  return date + "-" + month + "-" + year;
}

function findNextDate(day, month, year) {
  if (isLastDateOfYear(day, month)) {
    return formateDate(1, 1, year + 1);
  }
  if (isLastDateOfMonth(day, month, year)) {
    return formateDate(1, month + 1, year);
  }

  return formateDate(day + 1, month, year);
}

function nextDate(date) {
  let day = parseInt(date.slice(0, 2));
  let month = parseInt(date.slice(3, 5));
  let year = parseInt(date.slice(6, 10));

  if (isDateInvalid(day, month, year)) {
    return "Invalid Date";
  }

  return findNextDate(day, month, year);
}

function composeMessage(discription, date, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : [${date}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? messageForRight : messageForWrong;

  return message;
}

function testNextDate(discription, date, expected) {
  const actual = nextDate(date);
  const message = composeMessage(discription, date, actual, expected);

  console.log(message);
}

function testall() {
  testNextDate("simple increment in date", "03-02-2001", "04-02-2001");
  testNextDate("Simple increment of a normal day", "15-03-2021", "16-03-2021");
  testNextDate("Year less than 1000", "15-03-0112", "16-03-0112");
  testNextDate("Year less than 1000", "31-12-0009", "01-01-0010");
  testNextDate("Year is being changed", "31-12-2021", "01-01-2022");
  testNextDate("Month of only 30 days", "31-04-2021", "Invalid Date");
  testNextDate("Month of only 30 days being changed", "30-04-2023", "01-05-2023");
  testNextDate("Month of 31 days being changed", "30-07-2024", "31-07-2024");
  testNextDate("It is not a leap year", "29-02-2021", "Invalid Date");
  testNextDate("It is a leap year", "29-02-2024", "01-03-2024");
  testNextDate("It is not only a century leap year", "28-02-2000", "29-02-2000");
  testNextDate("It is century year not a leap year", "28-02-1900", "01-03-1900");
  testNextDate("Date can be minimum 01", "00-02-1900", "Invalid Date");
  testNextDate("Date can be maximum 31", "32-03-2021", "Invalid Date");
  testNextDate("February don't have more than 29 days", "30-02-2021", "Invalid Date");
  testNextDate("There are not months less than 01", "24-00-1998", "Invalid Date");
  testNextDate("There are not months more than 12", "24-13-1998", "Invalid Date");
  testNextDate("Simple increment Year is 0000", "29-02-0000", "Invalid Date");
  testNextDate("It is a leap year", "29-02-8368", "01-03-8368");
}

testall();