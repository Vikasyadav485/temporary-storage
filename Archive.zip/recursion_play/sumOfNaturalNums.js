function sumOfNaturalNums(a) {
  if (a === 0) {
    return 0;
  }
  return a + sumOfNaturalNums(a - 1);
}

console.log(sumOfNaturalNums(10));
console.log(sumOfNaturalNums(100));
console.log(sumOfNaturalNums(1000));