function sumOfGP(a, r, n) {
  if (n === 1) {
    return a;
  }
  return a + sumOfGP(a * r, r, n - 1);
}

function composeMessage(discription, a, r, n, actual, expected) {
  const rightMessage = `✅ ${discription}`;
  const wrongMessage = `❌ ${discription} \n \n input : [${a}, ${r}, ${n}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? rightMessage : wrongMessage;

  return message;
}

function testSumOfGP(discription, a, r, n, expected) {
  const actual = sumOfGP(a, r, n);
  const message = composeMessage(discription, a, r, n, actual, expected);

  console.log(message);
}

function testall(){
  testSumOfGP("simple positive first term and ration", 2, 3, 4, 80);
  testSumOfGP("simple positive first term and ration", 3, 4, 4, 255);
  testSumOfGP("simple positive first term and ration", 2, 2, 8, 510);
}

testall();