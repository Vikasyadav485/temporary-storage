function fibonacci(currentTerm, lastTerm, n){
  if (n === 1) {
    return currentTerm;
  }
  console.log(currentTerm);
  return fibonacci(currentTerm + lastTerm, currentTerm, n - 1);
}

function fibonacciSeries(n){
  return fibonacci(0, 1, n);
}

// console.log(fibonacciSeries(5));
// console.log(fibonacciSeries(10));
console.log(fibonacciSeries(30));
// console.log(fibonacciSeries(5));
// console.log(fibonacciSeries(5));