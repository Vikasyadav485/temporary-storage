function lastIndexFinder(string, char, index) {
  if (index === - 1) {
    return - 1;
  }
  if (char === string[index]) {
    return index;
  }

  return lastIndexFinder(string, char, index - 1);
}

function findLastIndex(string, char) {
  const lastIndex = lastIndexFinder(string, char, string.length - 1);

  return lastIndex;
}

function composeMessage(discription, string, char, actual, expected) {
  const rightMessage = `✅ ${discription}`;
  const wrongMessage = `❌ ${discription} \n \n input : [${string}, ${char}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? rightMessage : wrongMessage;

  return message;
}

function testFindLastIndex(discription, string, char, expected) {
  const actual = findLastIndex(string, char);
  const message = composeMessage(discription, string, char, actual, expected);

  console.log(message);
}

function testall() {
  testFindLastIndex("simple string.", "abcabcabcabc", "a", 9);
  testFindLastIndex("simple string.", "ram manohara lohia", "n", 6);
  testFindLastIndex("empty string", "", "e", -1);
  testFindLastIndex("empty string as char", "ram manohara lohia", "", -1);
  testFindLastIndex("spaces in string", "ram manohara lohia", " ", 12);
  testFindLastIndex("non existing char", "ram manohara lohia", "e", -1);
}

testall();