function reverseString(string, index) {
  if (index === - 1) {
    return "";
  }

  return string[index] + reverseString(string, index - 1);
}

function reverse(string) {
  const reversedString = reverseString(string, string.length - 1);

  return reversedString;
}

function composeMessage(discription, string, actual, expected) {
  const rightMessage = `✅ ${discription}`;
  const wrongMessage = `❌ ${discription} \n \n input : [${string}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? rightMessage : wrongMessage;

  return message;
}

function testReversedString(discription, string, expected) {
  const actual = reverse(string);
  const message = composeMessage(discription, string, actual, expected);

  console.log(message);
}

function testall() {
  testReversedString("simple string", "Thoughtworks", "skrowthguohT");
  testReversedString("string with spaces", "Thought works", "skrow thguohT");
  testReversedString("string with \\n ", "Thought \n works", "skrow \n thguohT");
  testReversedString("string with \\t ", "Thought \t works", "skrow \t thguohT");
  testReversedString("string with _", "Thought_works", "skrow_thguohT");
  testReversedString("empty string", "", "");
}

testall();