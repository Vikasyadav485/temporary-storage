function findNumber(string, stringIndex, index) {
  const numberString = "0123456789";

  if (string[stringIndex] === numberString[index]) {
    return index;
  }

  return findNumber(string, stringIndex, index + 1);
}

function changeNumber(string, power, index) {
  if(index === string.length) {
    return 0;
  }
  console.log(string[index]);
  return findNumber(string, index, 0) * 10 ** power + changeNumber(string, power - 1, index + 1);
}

function stringToNumber(string) {
  if (string[0] === "-") {
     return - 1 * changeNumber(string, string.length - 2, 1);
  }else{
    return changeNumber(string, string.length - 1, 0);
  }
}

function composeMessage(discription, string, actual, expected) {
  const rightMessage = `✅ ${discription}`;
  const wrongMessage = `❌ ${discription} \n \n input : [${string}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? rightMessage : wrongMessage;

  return message;
}

function testStringToNumber(discription, string, expected) {
  const actual = stringToNumber(string);
  const message = composeMessage(discription, string, actual, expected);

  console.log(message);
}

function testall() {
  testStringToNumber("simple single digit number string", "1", 1);
  testStringToNumber("simple string with only zero", "0", 0);
  testStringToNumber("simple number string", "234", 234);
  testStringToNumber("Starting with 0", "023", 23);
  testStringToNumber("simple number string", "456", 456);
  testStringToNumber("simple number string", "10", 10);
  testStringToNumber("negative number string", "-11", -11);
  testStringToNumber("negative number string", "-244", -244);
}

testall();
