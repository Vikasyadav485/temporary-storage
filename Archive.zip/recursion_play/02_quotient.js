function quotient(dividend, divisor) {
  if (dividend < divisor || dividend === 0) {
    return 0;
  }
  if (divisor === 0) {
    return Infinity;
  }

  return 1 + quotient(dividend - divisor, divisor);
}

function composeMessage(actual, expected) {
  const result = actual === expected ? "✅" : "❌";
  const message = `${result} | actual : ${actual} | expected : ${expected} |`;

  return message;
}

function testQuotient(dividend, divisor, expected) {
  const actual = quotient(dividend, divisor);
  const message = composeMessage(actual, expected);
  console.log(message);
}

function testall() {
  testQuotient(5, 2, 2);
  testQuotient(6, 2, 3);
  testQuotient(0, 2, 0);
  testQuotient(7, 0, Infinity);
  testQuotient(0, 0, 0)
}

testall();