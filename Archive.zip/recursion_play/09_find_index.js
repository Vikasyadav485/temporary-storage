function indexFinder(string, char, index) {
  if (index === string.length) {
    return -1;
  }
  if (char === string[index]) {
    return index;
  }

  return indexFinder(string, char, index + 1);
}

function findIndex(string, char) {
  const index = indexFinder(string, char, 0);

  return index;
}

function composeMessage(discription, string, char, actual, expected) {
  const rightMessage = `✅ ${discription}`;
  const wrongMessage = `❌ ${discription} \n \n input : [${string}, ${char}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? rightMessage : wrongMessage;

  return message;
}

function testFindIndex(discription, string, char, expected) {
  const actual = findIndex(string, char);
  const message = composeMessage(discription, string, char, actual, expected);

  console.log(message);
}

function testall() {
  testFindIndex("simple string.", "ram manohara lohia", "n", 6);
  testFindIndex("empty string", "", "e", -1);
  testFindIndex("empty string as char", "ram manohara lohia", "", -1);
  testFindIndex("spaces in string", "ram manohara lohia", " ", 3);
  testFindIndex("non existing char", "ram manohara lohia", "e", -1);
}

testall();