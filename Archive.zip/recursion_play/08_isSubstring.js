function isSubStringAt(string, otherString, index, stringIndex) {
  if (index === otherString.length) {
    return true;
  }
  if (otherString[index] !== string[stringIndex]) {
    return false;
  }

  return isSubStringAt(string, otherString, index + 1, stringIndex + 1);
}

function findFirstMatch(string, otherString, index) {
  if (index === string.length) {
    return false;
  }
  if (otherString[0] === string[index] && isSubStringAt(string, otherString, 0, index)) {
    return true;
  }

  return findFirstMatch(string, otherString, index + 1);
}

function isSubString(string, otherString) {
  const checkSubString = findFirstMatch(string, otherString, 0);

  return checkSubString;
}

function composeMessage(discription, string, otherString, actual, expected) {
  const rightMessage = `✅ ${discription}`;
  const wrongMessage = `❌ ${discription} \n \n input : [${string}, ${otherString}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? rightMessage : wrongMessage;

  return message;
}

function testIsSubString(discription, string, otherString, expected) {
  const actual = isSubString(string, otherString);
  const message = composeMessage(discription, string, otherString, actual, expected);

  console.log(message);
}

function testall() {
  testIsSubString("simple string", "mannadey", "na", true);
  testIsSubString("empty string", "mannadey", "", false);
  testIsSubString("empty string", "", "", false);
  testIsSubString("empty string", "", "a", false);
  testIsSubString("string with spaces", "mann   adey", "n   a", true);
  testIsSubString("string with _", "man_nadey", "_na", true);
  testIsSubString("string with \\t ", "man\tnadey", "na", true);
  testIsSubString("string with \\n ", "mann \n adey", "n \n a", true);
}

testall();
