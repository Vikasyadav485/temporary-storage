function findLength(index, limit) {
  return Math.floor(((limit * limit) - (index ** 2)) ** 0.5);
}

function totalLength(index, limit) {
  const length = findLength(index, limit);
  const extraPaddingLength = Math.floor(length - (length / 2));

  return length + extraPaddingLength;
}

function findPadLength(limit, length) {
  const redius = findLength(((limit / 3) + 1), limit);
  return (length + redius + 30) - (2 * length);
}

function main(limit) {
  const line = [];
  for (let index = limit; index > (limit / 3); index--) {

    // const length = totalLength(index, limit);
    // const padding = " ".repeat(length)+ "*";
    // line.push(padding);

    const length = totalLength(index, limit);
    const padding = " ".repeat(findPadLength(limit, length)) + "*";
    const secondPdding = " ".repeat(2 * length) + "*";
    line.push(padding + " " + secondPdding);

  }

  const upperQuarter = line.join("\n");
  const lowerQuarter = line.reverse().join("\n");

  console.log(upperQuarter + "\n" + lowerQuarter);
}




main(20);