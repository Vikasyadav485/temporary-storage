
//               8  8
//          8            8
//       8                  8
//     8                      8

//    8                        8

//     8                      8
//       8                  8
//          8            8
//               8  8




//            8  8
//       8            8
//    8                  8
//  8                      8

// 8                        8

//  8                      8
//    8                  8
//       8            8
//            8  8


// console.log("                 $      $\n");
// console.log("         $                      $\n");
// console.log("     $                              $\n");
// console.log("  $                                    $\n");
// console.log("\n");
// console.log("$                                        $\n");
// console.log("\n");
// console.log("  $                                    $\n");
// console.log("     $                             $\n");
// console.log("         $                     $\n");
// console.log("                 $      $\n");

function reverseString(string) {
  let reversedString = "";
  for (let index = string.length - 1; index >= 0; index--) {
    reversedString += string[index];
  }
  return reversedString;
}

function findLength(index, limit) {
  return Math.floor(((limit * limit) - (index ** 2)) ** 0.5);
}

function findPadLength(limit, length) {
  const redius = findLength((limit / 2) - 1, limit);
  return (length + redius) - (2 * length);
}

function circleRow(limit,index) {
  const length = findLength(index, limit);
  const padding = " ".repeat(findPadLength(limit, length)) + "*";
  const secondPdding = " ".repeat(2 * length) + "*";
  return padding + " " + secondPdding;
}
const line = [];

const limit = 40;

for (let index = limit; index > (limit / 2); index--) {
  // const length = Math.floor(1 * ((index) ** (2)));
  // const length = (index ** 2) / ();
  // const length = ((index) ** 2) - (2 * index);
  
  line.push(circleRow(limit,index));
}

const midLine = circleRow(limit, (limit / 2) + 1);

const upperHalf = line.join("\n");
const lowerHalf = line.reverse().join("\n");

console.log(upperHalf + "\n" + midLine + "\n" + lowerHalf);
