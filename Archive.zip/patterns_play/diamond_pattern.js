function generatePattern(style, dimensions) {
  let pattern = "";
  // let pattern2 = "";

  // for (let index = 2; index <= (dimensions[0] + 1) / 2; index++) {
  //   pattern1 += "\n" + " ".repeat(dimensions[0] - index) + "*".repeat(2 * index - 1);
  // }

  // for (let index = (dimensions[0] + 1) / 2 + 1; index >= 2; index++) {
  //   pattern2 += '\n' + " ".repeat(index - (dimensions[0] + 1) / 2) + "*".repeat()
  // }

  for (let index = 1; index <= (dimensions[0] - 1) / 2; index++) {
    pattern += "\n" + " ".repeat(dimensions[0] - index) + "*".repeat(2 * index - 1);
  }

  let pattern2 = "\n" + "*".repeat(dimensions[0]);
  pattern += pattern + pattern2 + pattern.reverse();

  return pattern;
}

function composeMessage(discription, style, dimensions, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : [${style}, [${dimensions}]]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? messageForRight : messageForWrong;

  return message;
}

function testGeneratePattern(discription, style, dimensions, expected) {
  const actual = generatePattern(style, dimensions);
  console.log(actual, expected);
  const message = composeMessage(discription, style, dimensions, actual, expected);

  console.log(message);
}

function testall() {
  testGeneratePattern("simple three row", "right-aligned-triangle", [5], "  *\n ***\n*****\n ***\n  *");
  // testGeneratePattern("simple 5 row", "right-aligned-triangle", [5], "    *\n   **\n  ***\n ****\n*****");
  // testGeneratePattern("zero row", "right-aligned-triangle", [0], "");
}

testall();
