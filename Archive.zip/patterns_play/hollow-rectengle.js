/*

generatePattern("hollow-rectangle", [4, 3]);
// Output:
****
*  *
****

generatePattern("hollow-rectangle", [5, 4]);
// Output:
*****
*   *
*   *
*****

generatePattern("hollow-rectangle", [6, 2]);
// Output:
******
******

generatePattern("hollow-rectangle", [5, 1]);
// Output:
*****

generatePattern("hollow-rectangle", [1, 5]);
// Output:
*
*
*
*
*

generatePattern("hollow-rectangle", [0, 3]);
// Output: (empty string)

generatePattern("hollow-rectangle", [7, 0]);
// Output: (empty string)
*/

function rowInHollowRectangle(dimensions) {
  let row = "";

  for(let index = 2; index <= dimensions[0]; index++) {
    if(index === dimensions[0]) {
      row += "*";
    } else {
    row += " ";
    }
  }

  return row;
}

function hollowRectenglePattern (dimensions) {
  let pattern = "*".repeat(dimensions[0]);

  for (let index = 2; index <= dimensions[1]; index++) {
    if(index === dimensions[1]) {
      pattern += "\n" + "*".repeat(dimensions[0]);
    } else {
    pattern += "\n" + "*" + rowInHollowRectangle(dimensions);
    }
  }

  return pattern;
}

function generatePattern(style, dimensions) {
  if (style === "hollow-rectengle") {
    return hollowRectenglePattern(dimensions);
  }
}

function composeMessage(discription, style, dimensions, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : [${style}, [${dimensions}]]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? messageForRight : messageForWrong;

  return message;
}

function testGeneratePattern(discription, style, dimensions, expected) {
  const actual = generatePattern(style, dimensions);
  const message = composeMessage(discription, style, dimensions, actual, expected);

  console.log(message);
}

function testall() {
  testGeneratePattern("with non-zero dimensions", "hollow-rectengle", [5, 3], `*****\n*   *\n*****`);
  testGeneratePattern("with non- zero dimensions", "hollow-rectengle", [3, 4], `***\n* *\n* *\n***`);
  testGeneratePattern("with zero columns", "hollow-rectengle", [0, 5], '');
  testGeneratePattern("with zero rows", "hollow-rectengle", [7, 0], '');
  testGeneratePattern("with zero rows", "hollow-rectengle", [5,1], '*****');
  testGeneratePattern("with zero rows", "hollow-rectengle", [1,5], '*\n*\n*\n*\n*');
}

testall();

// console.log(makeRowsBetween(4));







