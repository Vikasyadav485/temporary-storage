// function countOfSymbol(rows, index) {
//   return rows - Math.abs(rows + 1 - (2 * index));
// }

// function generateline(n, start = "*", mid = "*", end = "*") {
//   if (n <= 2) {
//     return (start + mid).slice(0, n);
//   }
//   return start + mid.repeat(n - 2) + end;
// }

// function paddedLength(rows, index) {
//   return rows - Math.abs(((rows + 1) / 2) - index);
// }

// function paddedLine(rows, index, mid) {
//   const line = generateline(countOfSymbol(rows, index), "*", mid);

//   return line.padStart(paddedLength(rows, index), " ");
// }

function countOfSymbol(rows, index) {
  return rows - Math.abs(rows + 1 - (2 * index));
}

function generateHollowLine(length, start = "*", mid = "*", end = "*") {
  if (length <= 2) {
    return (start + mid).slice(0, length);
  }
  return start + mid.repeat(length - 2) + end;
}

function generateFilledLine(length, char) {
  return char.repeat(length);
}

function paddedLengthDiamond(rows, index) {
  return rows - Math.abs(((rows + 1) / 2) - index);
}

function paddedLine(line, rows, index) {
  return line.padStart(paddedLengthDiamond(rows, index), " ");
}


function diamondPattern(size) {
  let lines = [];
  const noOfRows = size - ((size + 1) % 2);

  for (let index = 1; index <= noOfRows; index++) {
    const line = generateHollowLine(countOfSymbol(noOfRows, index), "*", " ");
    const padLine = paddedLine(line, noOfRows, index);

    lines.push(padLine);
  }
  return lines.join("\n");
}

console.log(diamondPattern(11));