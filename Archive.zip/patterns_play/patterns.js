
function dontHaveColumnOrRow(dimensions) {
  return dimensions[0] === 0 || dimensions[1] === 0;
}

function filledRectenglePattern(dimensions) {
  let pattern = '';

  for (let index = 1; index < dimensions[1]; index++) {
    pattern += "*".repeat(dimensions[0]) + "\n";
  }
  pattern += "*".repeat(dimensions[0]);

  return pattern;
}

function rowInHollowRectangle(dimensions) {
  let row = "";

  for (let index = 2; index <= dimensions[0]; index++) {
    if (index === dimensions[0]) {
      row += "*";
    } else {
      row += " ";
    }
  }

  return row;
}

function hollowRectanglePattern(dimensions) {
  let pattern = "*".repeat(dimensions[0]);

  for (let index = 2; index <= dimensions[1]; index++) {

    if (index === dimensions[1]) {
      pattern += "\n" + "*".repeat(dimensions[0]);
    } else {
      pattern += "\n" + "*" + rowInHollowRectangle(dimensions);
    }
  }

  return pattern;
}

function alternatingRectanglePattern(dimensions) {
  let pattern = "*".repeat(dimensions[0]);

  for (let index = 2; index <= dimensions[1]; index++) {
    if (index % 2 === 0) {
      pattern += "\n" + "-".repeat(dimensions[0]);
    } else {
      pattern += "\n" + "*".repeat(dimensions[0]);
    }
  }
  return pattern;
}

function spacedAlternatingRectangle(dimensions) {
  let pattern = "*".repeat(dimensions[0]);

  for (let index = 2; index <= dimensions[1]; index++) {
    if (index % 3 === 2) {
      pattern += "\n" + "-".repeat(dimensions[0]);
    } else if (index % 3 === 1) {
      pattern += "\n" + "*".repeat(dimensions[0]);
    } else {
      pattern += "\n" + " ".repeat(dimensions[0]);
    }
  }
  return pattern;
}

function trianglePattern(dimensions) {
  let pattern = "*";

  for (let index = 2; index <= dimensions[0]; index++) {
    pattern += "\n" + "*".repeat(index);
  }

  return pattern;
}

function rightAlignedTriangle(dimensions) {
  let pattern = " ".repeat(dimensions[0] - 1) + "*";

  for (let index = 2; index <= dimensions[0]; index++) {
    pattern += "\n" + " ".repeat(dimensions[0] - index) + "*".repeat(index);
  }

  return pattern;
}

function countOfSymbol(rows, index) {
  return rows - Math.abs(rows + 1 - (2 * index));
}

function generateHollowLine(length, start = "*", mid = "*", end = "*") {
  if (length <= 2) {
    return (start + mid).slice(0, length);
  }
  return start + mid.repeat(length - 2) + end;
}

function generateFilledLine(length, char) {
  return char.repeat(length);
}

function paddedLengthDiamond(rows, index) {
  return rows - Math.abs(((rows + 1) / 2) - index);
}

function paddedLine(line, rows, index) {
  return line.padStart(paddedLengthDiamond(rows, index), " ");
}

function diamondPattern(size) {
  let lines = [];
  const noOfRows = size - ((size + 1) % 2);

  for (let index = 1; index <= noOfRows; index++) {
    const line = generateFilledLine(countOfSymbol(noOfRows, index), "*")
    const padLine = paddedLine(line, noOfRows, index);

    lines.push(padLine);
  }

  return lines.join("\n");
}

function hollowDiamondPattern(size) {
  let lines = [];
  const noOfRows = size - ((size + 1) % 2);

  for (let index = 1; index <= noOfRows; index++) {
    const line = generateHollowLine(countOfSymbol(noOfRows, index), "*"," ");
    const padLine = paddedLine(line, noOfRows, index);

    lines.push(padLine);
  }
  return lines.join("\n");
}


function generatePattern(style, dimensions) {
  if (dontHaveColumnOrRow(dimensions)) {
    return "";
  }
  if (style === "filled-rectangle") {
    return filledRectenglePattern(dimensions);
  }
  if (style === "hollow-rectangle") {
    return hollowRectanglePattern(dimensions);
  }
  if (style === "alternating-rectangle") {
    return alternatingRectanglePattern(dimensions);
  }
  if (style === "spaced-alternating-rectangle") {
    return spacedAlternatingRectangle(dimensions);
  }
  if (style === "triangle") {
    return trianglePattern(dimensions)
  }
  if (style === "right-aligned-triangle") {
    return rightAlignedTriangle(dimensions);
  }
  if (style === "diamond") {
    return diamondPattern(dimensions[0]);
  }
  if(style === "hollow-diamond") {
    return hollowDiamondPattern(dimensions[0]);
  }
}

function composeMessage(discription, style, dimensions, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : [${style}, [${dimensions}]]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? messageForRight : messageForWrong;

  return message;
}

function testGeneratePattern(discription, style, dimensions, expected) {
  const actual = generatePattern(style, dimensions);
  const message = composeMessage(discription, style, dimensions, actual, expected);

  console.log(message);
}

function underline(text){
  console.log(text,"\n" + "-".repeat(text.length));
}

function testFilledRectangle() {
  underline("filled-rectangle");
  testGeneratePattern("with non-zero dimensions", "filled-rectangle", [5, 3], `*****\n*****\n*****`);
  testGeneratePattern("with non- zero dimensions", "filled-rectangle", [2, 4], `**\n**\n**\n**`);
  testGeneratePattern("with zero columns", "filled-rectangle", [0, 5], '');
  testGeneratePattern("with zero rows", "filled-rectangle", [7, 0], '');
  console.log("\n");
}

function testHollowRectangle() {
  underline("hollow-rectangle");
  testGeneratePattern("with non-zero dimensions", "hollow-rectangle", [5, 3], `*****\n*   *\n*****`);
  testGeneratePattern("with non- zero dimensions", "hollow-rectangle", [3, 4], `***\n* *\n* *\n***`);
  testGeneratePattern("with zero columns", "hollow-rectangle", [0, 5], '');
  testGeneratePattern("with zero rows", "hollow-rectangle", [7, 0], '');
  testGeneratePattern("with zero rows", "hollow-rectangle", [5, 1], '*****');
  testGeneratePattern("with zero rows", "hollow-rectangle", [1, 5], '*\n*\n*\n*\n*');
  console.log("\n");
}

function testAlternatingRectangle() {
  underline("alternating-rectangle");
  testGeneratePattern("with non-zero dimensions", "alternating-rectangle", [5, 3], `*****\n-----\n*****`);
  testGeneratePattern("with non- zero dimensions", "alternating-rectangle", [3, 4], `***\n---\n***\n---`);
  testGeneratePattern("with zero columns", "alternating-rectangle", [0, 5], '');
  testGeneratePattern("with zero rows", "alternating-rectangle", [7, 0], '');
  testGeneratePattern("single row", "alternating-rectangle", [5, 1], '*****');
  testGeneratePattern("single column", "alternating-rectangle", [1, 5], '*\n-\n*\n-\n*');
  console.log("\n");
}

function testSpacedAlternatingRectangle(){
  underline("spaced-alternating-rectangle");
  testGeneratePattern("with non-zero dimensions", "spaced-alternating-rectangle", [5, 3], `*****\n-----\n     `);
  testGeneratePattern("with non- zero dimensions", "spaced-alternating-rectangle", [3, 4], `***\n---\n   \n***`);
  testGeneratePattern("with zero columns", "spaced-alternating-rectangle", [0, 5], '');
  testGeneratePattern("with zero rows", "spaced-alternating-rectangle", [7, 0], '');
  testGeneratePattern("single row", "spaced-alternating-rectangle", [5, 1], '*****');
  testGeneratePattern("single column", "spaced-alternating-rectangle", [1, 5], '*\n-\n \n*\n-');
  console.log("\n");
}

function testTiangle(){
  underline("triangle");
  testGeneratePattern("simple three row", "triangle", [4], "*\n**\n***\n****");
  testGeneratePattern("simple 5 row", "triangle", [5], "*\n**\n***\n****\n*****");
  testGeneratePattern("zero row", "triangle", [0], "");
  testGeneratePattern("single row", "triangle", [1], "*");
  console.log("\n");
}

function testRightAlignedTriangle(){
  underline("right-aligned-triangle");
  testGeneratePattern("simple three row", "right-aligned-triangle", [4], "   *\n  **\n ***\n****");
  testGeneratePattern("simple 5 row", "right-aligned-triangle", [5], "    *\n   **\n  ***\n ****\n*****");
  console.log("\n");
}

function testDiamond(){
  underline("diamond");
  testGeneratePattern("zero row", "diamond", [0], "");
  testGeneratePattern("one row", "diamond", [1], "*");
  testGeneratePattern("size in even", "diamond", [4], " *\n***\n *");
  testGeneratePattern("size of odd", "diamond", [7], "   *\n  ***\n *****\n*******\n *****\n  ***\n   *");
  console.log("\n");
}

function testHollowDiamond(){
  underline("hollow-diamond");
  testGeneratePattern("zero row", "hollow-diamond", [0], "");
  testGeneratePattern("one row", "hollow-diamond", [1], "*");
  testGeneratePattern("size in even", "hollow-diamond", [4], " *\n* *\n *");
  testGeneratePattern("size of odd", "hollow-diamond", [7], "   *\n  * *\n *   *\n*     *\n *   *\n  * *\n   *");
  console.log("\n");
}

function testall() {
  testFilledRectangle();
  testHollowRectangle();
  testAlternatingRectangle();
  testSpacedAlternatingRectangle();
  testTiangle();
  testRightAlignedTriangle();
  testDiamond();
  testHollowDiamond();
}

testall();