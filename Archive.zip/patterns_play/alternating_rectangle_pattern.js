/* 
generatePattern("alternating-rectangle", [3, 3]);
// Output:
***
---
***

generatePattern("alternating-rectangle", [5, 4]);
// Output:
*****
-----
*****
-----

generatePattern("alternating-rectangle", [6, 2]);
// Output:
******
------

generatePattern("alternating-rectangle", [4, 1]);
// Output:
****

generatePattern("alternating-rectangle", [0, 5]);
// Output: (empty string)

generatePattern("alternating-rectangle", [7, 0]);
// Output: (empty string)
*/

function spacedAlternatingRectangle(dimensions, character) {
    return "\n" + character.repeat(dimensions[0]);
}

function generatePattern (style, dimensions) {
  let pattern = "*".repeat(dimensions[0]);

  for (let index = 2; index <= dimensions[1]; index++) {
    pattern += (index % 2 === 0) ? spacedAlternatingRectangle(dimensions, "-"): spacedAlternatingRectangle(dimensions, "*");
  }
  return pattern;
}

function composeMessage(discription, style, dimensions, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : [${style}, [${dimensions}]]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? messageForRight : messageForWrong;

  return message;
}

function testGeneratePattern(discription, style, dimensions, expected) {
  const actual = generatePattern(style, dimensions);
  const message = composeMessage(discription, style, dimensions, actual, expected);

  console.log(message);
}

function testall() {
  testGeneratePattern("with non-zero dimensions", "hollow-rectengle", [5, 3], `*****\n-----\n*****`);
  testGeneratePattern("with non- zero dimensions", "hollow-rectengle", [3, 4], `***\n---\n***\n---`);
  testGeneratePattern("with zero columns", "hollow-rectengle", [0, 5], '');
  testGeneratePattern("with zero rows", "hollow-rectengle", [7, 0], '');
  testGeneratePattern("single row", "hollow-rectengle", [5,1], '*****');
  testGeneratePattern("single column", "hollow-rectengle", [1,5], '*\n-\n*\n-\n*');
}

testall();
