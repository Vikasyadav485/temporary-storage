function rowAlternatingRectangle(dimensions, character) {
  return "\n" + character.repeat(dimensions[0]);
}

function characterSelect(dimensions, number) {
  switch (number) {
    case (1):
      return rowAlternatingRectangle(dimensions, "*");
    case (2):
      return rowAlternatingRectangle(dimensions, "-");
    case (0):
      return rowAlternatingRectangle(dimensions, " ");
  }
}

function generatePattern(style, dimensions) {
  let pattern = "*".repeat(dimensions[0]);

  for (let index = 2; index <= dimensions[1]; index++) {
    pattern += characterSelect(dimensions, index % 3);
  }
  return pattern;
}

function composeMessage(discription, style, dimensions, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : [${style}, [${dimensions}]]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? messageForRight : messageForWrong;

  return message;
}

function testGeneratePattern(discription, style, dimensions, expected) {
  const actual = generatePattern(style, dimensions);
  const message = composeMessage(discription, style, dimensions, actual, expected);

  console.log(message);
}

function testall() {
  testGeneratePattern("with non-zero dimensions", "spaced-alternating-rectangle", [5, 3], `*****\n-----\n     `);
  testGeneratePattern("with non- zero dimensions", "spaced-alternating-rectangle", [3, 4], `***\n---\n   \n***`);
  testGeneratePattern("with zero columns", "spaced-alternating-rectangle", [0, 5], '');
  testGeneratePattern("with zero rows", "spaced-alternating-rectangle", [7, 0], '');
  testGeneratePattern("single row", "spaced-alternating-rectangle", [5, 1], '*****');
  testGeneratePattern("single column", "spaced-alternating-rectangle", [1, 5], '*\n-\n \n*\n-');
}

testall();
