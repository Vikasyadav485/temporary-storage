function countOfSymbol(rows, index) {
  return rows - Math.abs(rows + 1 - (2 * index));
}

function generateHollowLine(length, start = "*", mid = "*", end = "*") {
  if (n <= 2) {
    return (start + mid).slice(0, length);
  }
  return start + mid.repeat(length - 2) + end;
}

function generateFilledLine(length, char) {
  return char.repeat(length);
}

function paddedLengthDiamond(rows, index) {
  return rows - Math.abs(((rows + 1) / 2) - index);
}

function paddedLine(line, rows, index) {
  return line.padStart(paddedLengthDiamond(rows, index), " ");
}

function diamondPattern(size) {
  let lines = [];
  const noOfRows = size - ((size + 1) % 2);

  for (let index = 1; index <= noOfRows; index++) {
    const line = generateFilledLine(countOfSymbol(noOfRows, index), "*");
    const padLine = paddedLine(line, noOfRows, index);

    lines.push(padLine);
  }
  return lines.join("\n");
}

function generatePattern(style, dimensions) {
  if (style === "diamond") {
    return diamondPattern(dimensions);
  }
}

function testall() {
  console.log(generatePattern("diamond", 7));
}

testall();  