function generatePattern(style, dimensions) {
  let pattern = " ".repeat(dimensions[0] - 1) + "*";

  for (let index = 2; index <= dimensions[0]; index++) {
    pattern += "\n" + " ".repeat(dimensions[0] - index) + "*".repeat(index);
  }

  return pattern;
}

function composeMessage(discription, style, dimensions, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : [${style}, [${dimensions}]]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? messageForRight : messageForWrong;

  return message;
}

function testGeneratePattern(discription, style, dimensions, expected) {
  const actual = generatePattern(style, dimensions);
  const message = composeMessage(discription, style, dimensions, actual, expected);

  console.log(message);
}

function testall() {
  testGeneratePattern("simple three row", "right-aligned-triangle", [4], "   *\n  **\n ***\n****");
  testGeneratePattern("simple 5 row", "right-aligned-triangle", [5], "    *\n   **\n  ***\n ****\n*****");
  testGeneratePattern("zero row", "right-aligned-triangle", [0], "");
}

testall();
