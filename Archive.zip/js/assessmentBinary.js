let value = 19;
let modulus;
let multiplier = 1;
let numBinary = 0;

while(value > 0){
    modulus = value % 2;
    value = (value - modulus) / 2;
    modulus = modulus * multiplier;
    multiplier = multiplier * 10;
    numBinary = numBinary + modulus;
}
console.log(numBinary);