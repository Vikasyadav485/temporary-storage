const inputStudentAge = 8;

if(inputStudentAge <= 12){
    console.log("This is a kid.");
}else if(inputStudentAge <= 19){
    console.log("This is a teenager.");
}else{
    console.log("This is an adult.");
}