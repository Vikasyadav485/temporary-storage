let input = 4;
let factorial = input;

while(input > 1){
    input--;
    factorial = factorial * input;
}
console.log(factorial);