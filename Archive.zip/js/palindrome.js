const inputNum = 123443321;
let num = "" + inputNum;
let palindrome = false;

for(let count = 1; count <= num.length/2; count++){
    // console.log(num.length);
    if(num[num.length - count] - num[count -1] === 0){
        palindrome = true;
    }else{
        palindrome = false;
    }
}

let condition = (palindrome)? "is a palindrome.": "is not a palindrome.";

console.log(num,condition);