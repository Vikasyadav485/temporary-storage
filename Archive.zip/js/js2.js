let num = 19;
let remainder;
let remainder1;
let combinationFound = 0;
let firstLetter = 0;
let secondLetter = 1;

while (num >= 1){
    remainder = num % 2;
    console.log(remainder);
    if(num % 2 === 0){
        num = num / 2;
    }else {
        num = (num - 1) /2;
    }
    if(remainder === secondLetter && firstLetter != 0){
       if(num % 2 === firstLetter){
        combinationFound++;
       } 
    }
}
console.log("Total found combinations are",combinationFound);