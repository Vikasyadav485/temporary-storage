const a = [3,45,55,57,8,23];

const b = a[a.push(4) - 1];

console.log(b);