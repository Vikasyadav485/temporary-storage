let num = ".";
const total = ".......";
let sum = "";

while(num.length <= total.length){
    sum = sum + num;
    num = num + ".";
}

console.log(sum,sum.length);