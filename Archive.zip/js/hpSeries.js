const firstTerm = 2;
const differene = 3;
const terms = 1;
let preValue = firstTerm;
let denominator = preValue;
let numerator =1;

for(let count = 1; count <= terms; count++){
    console.log("1 /",preValue);
    let currentValue = preValue + differene;
    numerator = (numerator * currentValue) +denominator;
    denominator = denominator * currentValue;
    preValue = currentValue;
}

console.log(numerator,"/",denominator);