const lion = "L";
const zeb = "Z";
let ani = "";
let posLion = 0;
let posZeb = 0;
let count = 0;
const input = "L  L L L  L";
let distance1;
let distance = 101;

while(count < input.length){
    ani = input[count];
    if(ani === lion){
        posLion = count + 1;
    }
    if(ani === zeb){
        posZeb = count + 1;
    }
    if(posLion !== 0 && posZeb !== 0 ){
    distance1 = posZeb - posLion;
    }
    console.log(distance1);
    if (distance1 < 0){
        distance1 = distance1 * (-1);
    }
    console.log(distance1,"distance1");
    console.log(distance,"distance");
    if(distance1 < distance){
        distance = distance1;
    }
    count++;
}
console.log(distance,"outer distance");
if(distance === 101){
    distance = 0;
}
console.log(distance);
console.log(distance-1);