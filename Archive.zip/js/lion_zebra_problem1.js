const lion = "L";
const zeb = "Z";
let ani = "";
const input = "L   LZ"
let count = 0;
let distance;

while(inputNum < input.length){
    ani = input[inputNum];
    console.log("under first while",inputNum);
    console.log("under first while",ani);
    if(ani === lion){
        let count1 = inputNum + 1;
        let ani2;

        console.log("under first if",inputNum);
        console.log("under first if",ani);
    
        while(count1 <= input.length+1 && ani2 !== zeb){
            ani2 = input[count1];
            console.log("under second while",count1);
            distance = count1 - inputNum -1;
            count1++;
        }
        if(ani2 !==zeb){distance = -1}
        ani = ani2;
        inputNum = count1;
    }
    inputNum ++;
}
console.log(distance);