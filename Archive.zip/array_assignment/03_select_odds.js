// Given an array of numbers return a new array containing only odd elements of the
// original array.
// selectOdds([3, 2, 4, 5, 7]) => [3, 5, 7]
// selectOdds([2, 4, 6]) => []
// Do not modify the input array.

function checkEquality(array1, array2) {
  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function selectOdds(numbers) {
  const selectedOdds = [];

  for (let index = 0; index < numbers.length; index++) {
    if (numbers[index] % 2 === 1) {
      selectedOdds.push(numbers[index]);
    }
  }

  return selectedOdds;
}

function composeMessage(discription, numbers, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : | [${numbers}] |
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = checkEquality(actual, expected) ? messageForRight : messageForWrong;

  return message;
}

function testSelectOdds(discription, numbers, expected) {
  const actual = selectOdds(numbers);
  const message = composeMessage(discription, numbers, actual, expected);

  console.log(message);
}

function testall() {
  testSelectOdds("simple array", [1, 2, 3, 4, 5, 6, 7], [1, 3, 5, 7]);
  testSelectOdds("array with string", [1, 2, 3, "array", 5, 6, 7], [1, 3, 5, 7]);
  testSelectOdds("simple array", [1, 58, 45, 76, 7], [1, 45, 7]);
  testSelectOdds("simple array", [552, 783, 87], [783, 87]);
  testSelectOdds("array with only even numbers", [2, 4, 6], []);
  testSelectOdds("empty array", [], []);
}

testall();