// Given an array return reverse of array. DO NOT USE `.reverse()` function
// Write your own implementation of reverse
// reverse([1, 2, 3]) => [3, 2, 1]
// reverse([]) => []
// do not modify input parameters

function checkEquality(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function reverse(array) {
  let reversedArray = [];

  for (let index = 0; index < array.length; index++) {
    reversedArray[index] = array[array.length - 1 - index];
  }

  return reversedArray;
}

function composeMessage(discription, array, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : [[${array}]]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = checkEquality(actual, expected) ? messageForRight : messageForWrong;

  return message;
}

function testReverse(discription, array, expected) {
  const actual = reverse(array);
  const message = composeMessage(discription, array, actual, expected);

  console.log(message);
}

function testall() {
  testReverse("simple array", [2, 43, 67, 87], [87, 67, 43, 2]);
  testReverse("array with string", [2, 43, "fire exit", 87], [87, "fire exit", 43, 2]);
  testReverse("array with empty string", [2, "", 67, 87], [87, 67, "", 2]);
  testReverse("empty array", [], []);
}

testall();