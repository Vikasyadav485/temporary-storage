// Write a function that gives first n elements of fibonacci in reverse order
// fibonacci(5) => [3, 2, 1, 1, 0]
// do not modify input parameters

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function fibonacciSeries(numberOfTerm) {
  let currentTerm = 0;
  let nextTerm = 1;

  for (let index = 2; index <= numberOfTerm; index++) {
    currentTerm = currentTerm + nextTerm;
    nextTerm = currentTerm - nextTerm;
  }

  return currentTerm;
}

function reverseFibonacci(numberOfTerm) {
  let reversedFibonacciArray = [];

  for (let index = 0; index < numberOfTerm; index++) {
    reversedFibonacciArray[index] = fibonacciSeries(numberOfTerm - index);
  }

  return reversedFibonacciArray;
}

function composeMessage(discription, numberOfTerm, actual, expected) {
  const right = `✅ ${discription}`;
  const wrong = `❌ ${discription}
  input    : | ${numberOfTerm} |
  actual   : [${actual}]
  expected : [${expected}]
  ----------- \n`;

  const message = areEqual(actual, expected) ? right : wrong;

  return message;
}

function testReverseFibonacci(discription, numberOfTerm, expected) {
  const actual = reverseFibonacci(numberOfTerm);
  const message = composeMessage(discription, numberOfTerm, actual, expected);

  console.log(message);
}

function testall() {
  testReverseFibonacci("fibonacci series", 5, [3, 2, 1, 1, 0]);
  testReverseFibonacci("fibonacci series", 6, [5, 3, 2, 1, 1, 0]);
  testReverseFibonacci("fibonacci series", 9, [21, 13, 8, 5, 3, 2, 1, 1, 0]);
  testReverseFibonacci("fibonacci series", 2, [1, 0]);
  testReverseFibonacci("there is not any zeroth term", 0, [56]);
}

testall();