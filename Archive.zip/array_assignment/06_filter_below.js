// Given an array of numbers and a threshold value, return a new array
// that contains all the numbers which are below threshold.
// filterBelow([6, 2, 3, 1, 4, 7], 3) => [2, 1]
// filterBelow([1, 2, 3], 0) => []
// do not modify input parameters

function checkEquality(array1, array2) {
  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function filterBelow(array, threshold) {
  let filteredArray = [];

  for (let index = 0; index < array.length; index++) {
    if (array[index] < threshold) {
      filteredArray.push(array[index]);
    }
  }

  return filteredArray;
}

function composeMessage(discription, array, threshold, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : [[${array}], ${threshold}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = checkEquality(actual, expected) ? messageForRight : messageForWrong;

  return message;
}

function testFilterBelow(discription, array, threshold, expected) {
  const actual = filterBelow(array, threshold);
  const message = composeMessage(discription, array, threshold, actual, expected);

  console.log(message);
}

function testall() {
  testFilterBelow("simple array of numbers", [6, 2, 3, 1, 4, 7], 3, [2, 1]);
  testFilterBelow("not a single number less than threshold", [1, 2, 3], 0, []);
  testFilterBelow("all numbers are less than threshold", [6, 2, 3, 8, 4, 7], 9, [6, 2, 3, 8, 4, 7]);
}

testall();