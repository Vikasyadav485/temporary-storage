// Given array1 and array2, returns true if both arrays are deeply equal, else false.
// Deep equality means both arrays contain the same elements in the same order,
// including any nested arrays, which must also be deeply equal.
// Examples:
// areDeepEqual([1, 2, 3], [1, 2, 3]) => true
// areDeepEqual([1, [2, 3]], [1, [2, 3]]) => true
// areDeepEqual([1, [2, 3]], [1, [3, 2]]) => false
// areDeepEqual([1, 2], [1, 2, 3]) => false
// areDeepEqual([1, [2, [3]]], [1, [2, [3]]]) => true
// areDeepEqual([1, [2, [3]]], [1, [2, 3]]) => false
// do not modify input parameters

function areTypesNotSame(array1, array2) {
  return typeof array1 !== typeof array2;
}

function areLengthsNotEqual(array1, array2) {
  return array1.length !== array2.length;
}

function areDeepEqual(array1, array2) {
  if (areTypesNotSame(array1, array2)) {
    return false;
  }
  if (areLengthsNotEqual(array1, array2)) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (typeof array1[index] === "object") {
      return areDeepEqual(array1[index], array2[index]);
    }

    if (array1[index] !== array2[index]) {
      return false
    }
  }

  return true;
}

function composeMessage(discription, array1, array2, actual, expected) {
  const right = `✅ ${discription}`;
  const wrong = `❌ ${discription}
  input    : | [${array1}], [${array2}] |
  actual   : ${actual}
  expected : ${expected}
  ----------- \n`;

  const message = actual === expected ? right : wrong;

  return message;
}

function testAreDeepEqual(discription, array1, array2, expected) {
  const actual = areDeepEqual(array1, array2);
  const message = composeMessage(discription, array1, array2, actual, expected);

  console.log(message);
}

function testall() {
  testAreDeepEqual("simple arrays with elements", [1, 2, 3], [1, 2, 3], true);
  testAreDeepEqual("empty nested arrays", [[[], []], []], [[[]], []], false);
  testAreDeepEqual("string and array for comparison", "abc", ['a', 'b', 'c'], false);
  testAreDeepEqual("string and array as element", [1, [6, "abc"]], [1, [6, ['a', 'b', 'c']]], false);
  testAreDeepEqual("undefined as element in array", [1, [6, "undefined"]], [1, [6, "undefined"]], true);
  testAreDeepEqual("arrays with different length", [1, 2], [1, 2, 3], false);
  testAreDeepEqual("array as an element", [1, [2, 3]], [1, [2, 3]], true);
  testAreDeepEqual("array as an element", [1, [2, 3]], [1, [3, 2]], false);
  testAreDeepEqual("multi stage array", [1, [2, [3]]], [1, [2, [3]]], true);
  testAreDeepEqual("multi stage array", [1, [2, [3]]], [1, [2, 3]], false);
  testAreDeepEqual("string only", "high", "high", true);
}

testall();