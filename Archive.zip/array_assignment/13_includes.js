// Given an array and a value, returns true if the value is present in the array, else false.
// Examples:
// includes([1, 2, 3], 2) => true
// includes([1, 2, 3], 4) => false
// includes([], 1) => false
// do not modify input parameters

function isArray(x) {
  return typeof x === 'object';
}

function areArraysEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (!areDeepEqual(array1[index], array2[index])) {
      return false;
    }
  }

  return true;
}

function areDeepEqual(array1, array2) {
  if (typeof array1 !== typeof array2) {
    return false;
  }

  if (isArray(array1) && isArray(array2)) {
    return areArraysEqual(array1, array2);
  }

  return array1 === array2;
}

function includes(array, target) {
  
  for(let index = 0; index < array.length; index++) {
    if(areDeepEqual(array[index], target)){
      return true;
    }
  }

  return false;
}

function composeMessage(discription, array, target, actual, expected) {
  const right = `✅ ${discription}`;
  const wrong = `❌ ${discription}
  input    : | [${array}], [${target}] |
  actual   : ${actual}
  expected : ${expected}
  ----------- \n`;

  const message = actual === expected ? right : wrong;

  return message;
}

function testIncludes(discription, array, target, expected) {
  const actual = includes(array, target);
  const message = composeMessage(discription, array, target, actual, expected);

  console.log(message);
}

function testall() {
  testIncludes("simple array", [1, 2, 3], 2, true);
  testIncludes("element doesn't exist in array", [1, 2, 3], 4, false);
  testIncludes("empty array", [], 1, false);
  testIncludes("array with string", ["match", 4, 6], "match", true);
  testIncludes("array as an element", [1, 2, [3]], [3], true);
  testIncludes("array as an element", [1, [4,5],[3]], [4,5], true);
}

testall();