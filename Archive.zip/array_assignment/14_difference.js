// Return all the elements of array1 which are not present in array2.
// difference([1, 2, 3], [2, 3, 4]) => [1]

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index] || array1[index] === "") {
      return false;
    }
  }

  return true;
}

function isArray(x) {
  return typeof x === 'object';
}

function areArraysEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (!areDeepEqual(array1[index], array2[index])) {
      return false;
    }
  }

  return true;
}

function areDeepEqual(array1, array2) {
  if (typeof array1 !== typeof array2) {
    return false;
  }

  if (isArray(array1) && isArray(array2)) {
    return areArraysEqual(array1, array2);
  }

  return array1 === array2;
}

function includes(array, target) {

  for (let index = 0; index < array.length; index++) {
    if (areDeepEqual(array[index], target)) {
      return true;
    }
  }

  return false;
}

function difference(array1, array2) {
  let differenceArray = [];

  for (let index = 0; index < array1.length; index++) {

    if (!includes(array2, array1[index])) {
      differenceArray.push(array1[index]);
    }
  }

  return differenceArray;
}

function composeMessage(discription, array1, array2, actual, expected) {
  const right = `✅ ${discription}`;
  const wrong = `❌ ${discription}
  input    : | [${array1}], [${array2}] |
  actual   : ${actual}
  expected : ${expected}
  ----------- \n`;

  const message = areEqual(actual, expected) ? right : wrong;

  return message;
}

function testDifference(discription, array1, array2, expected) {
  const actual = difference(array1, array2);
  const message = composeMessage(discription, array1, array2, actual, expected);

  console.log(message);
}

function testall() {
  testDifference("simple array", [1, 2, 3], [2, 3, 4], [1]);
  testDifference("simple array", [1, 2, 67, 3], [1, 2, 3, 4], [67]);
  testDifference("array with string", [1, 2, 67, "sambahadur"], [1, 2, 3, 4], [67, "sambahadur"]);
  testDifference("not a single element matches", [15, 67, 34, "classmate"], [1, 2, 3, 4], [15, 67, 34, "classmate"]);
}

testall();