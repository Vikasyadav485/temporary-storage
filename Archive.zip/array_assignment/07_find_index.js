// Given an array of numbers and a element, return the first index in the array
// where element is present else -1
// findIndex(["apple", "cake", "tea", "coffee", "tea"], "tea") => 2
// do not modify input parameters

function findIndex(array, element) {
  for (let index = 0; index < array.length; index++) {
    if (array[index] === element) {
      return index;
    }
  }

  return -1;
}

function composeMessage(discription, array, element, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : [[${array}], ${element}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? messageForRight : messageForWrong;

  return message;
}

function testFindIndex(discription, array, element, expected) {
  const actual = findIndex(array, element);
  const message = composeMessage(discription, array, element, actual, expected);

  console.log(message);
}

function testall() {
  testFindIndex("simple array with strings only", ["apple", "cake", "tea", "coffee", "tea"], "tea", 2);
  testFindIndex("array with strings and numbers", ["apple", 44, "tea", 87, "tea"], 87, 3);
  testFindIndex("doesn't match any element", ["apple", "cake", "tea", "coffee", "tea"], "tata", -1);
  testFindIndex("simple array with numbers only", [67, 878, 98, 43, 54], 878, 1);
}

testall();