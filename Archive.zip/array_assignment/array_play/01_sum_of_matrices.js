function areEqual(matrix1, matrix2) {
  if (matrix1.length !== matrix2.length) {
    return false;
  }

  for (let index = 0; index < matrix1.length; index++) {

    if (typeof matrix1[index] === "object") {
      return areEqual(matrix1[index], matrix2[index]);
    }
    if (matrix1[index] !== matrix2[index]) {
      return false
    }
  }

  return true;
}

function areAddinable(matrix1, matrix2) {
  if (matrix1.length !== matrix2.length) {
    return false;
  }

  for (let index = 0; index < matrix1.length; index++) {
    if (matrix1[index].length !== matrix2[index].length) {
      return false;
    }
  }
  return true;
}

function rowOfSumMatrix(rowMatrix1, rowMatrix2) {
  let row =[];
  for (let index = 0; index < rowMatrix1.length; index++) {
    row.push(rowMatrix1[index] + rowMatrix2[index]);
  }
  return row;
}

function sumOfMatrices(matrix1, matrix2) {
  if (!areAddinable) {
    return false;
  }
  let summationArray = [];

  for(let index = 0; index < matrix1.length; index++) {
    summationArray.push(matrix1[index], matrix2[index]);
  }
  return summationArray;
}

function composeMessage(discription, matrix1, matrix2, actual, expected) {
  const right = `✅ ${discription}`;
  const wrong = `❌ ${discription}
  input    : | [${matrix1}], [${matrix2}] |
  actual   : [${actual}]
  expected : [${expected}]
  ----------- \n`;

  const message = areEqual(actual, expected) ? right : wrong;

  return message;
}

function testSumOfMatrices(discription, matrix1, matrix2, expected) {
  const actual = sumOfMatrices(matrix1, matrix2);
  const message = composeMessage(discription, matrix1, matrix2, actual, expected);

  console.log(message);
}

function testall() {
  testSumOfMatrices("simple additionable matrices", [[1, 2], [3, 4]], [[5, 6], [9, 10]], [[6, 8], [12, 14]]);
}

testall();


// console.log(areAddinable([[1, 2], [3, 4]], [[5, 6], [9, 10], [6, 7]]));