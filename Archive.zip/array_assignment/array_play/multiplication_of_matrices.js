function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {

    if (typeof array1[index] === "object") {
      return areEqual(array1[index], array2[index]);
    }
    if (array1[index] !== array2[index]) {
      return false
    }
  }

  return true;
}

function areMultiplicable(matrix1, matrix2) {
  for (let index = 0; index < matrix1.length; index++) {

    if (matrix2.length !== matrix1[index].length) {
      return false;
    }
  }

  return true;
}

function elementMultiplication(row, matrix2, i, index) {
  if (index === row.length) {
    return 0;
  }

  return row[index] * matrix2[index][i] + elementMultiplication(row, matrix2, i, index + 1);
}

function rowElements(row, matrix2, i) {
  let finalMatrixRowElements = [];
  for (let index = 0; index < matrix2[0].length; index++) {
    finalMatrixRowElements.push(elementMultiplication(row, matrix2, index, 0));
  }
  return finalMatrixRowElements;
}

function multiplication(matrix1, matrix2) {
  if (!areMultiplicable(matrix1, matrix2)) {
    return "Not Multiplicable";
  }
  let finalMatrixRow = [];

  for (let index = 0; index < matrix1.length; index++) {
    finalMatrixRow.push(rowElements(matrix1[index], matrix2, index));
  }

  return finalMatrixRow;
}


function composeMessage(discription, matrix1, matrix2, actual, expected) {
  const right = `✅ ${discription}`;
  const wrong = `❌ ${discription}
  input    : | [${matrix1}], [${matrix2}] |
  actual   : [${actual}]
  expected : [${expected}]
  ----------- \n`;

  const message = areEqual(actual, expected) ? right : wrong;

  return message;
}

function testMultiplication(discription, matrix1, matrix2, expected) {
  const actual = multiplication(matrix1, matrix2);
  const message = composeMessage(discription, matrix1, matrix2, actual, expected);

  console.log(message);
}

function testall() {
  testMultiplication("simple multiplicable matrices", [[1, 2, 3], [4, 5, 6]], [[8, 9], [4, 2], [6, 7]], [[34, 34], [88, 88]]);
  testMultiplication("simple multiplicable matrices", [[2, 1], [1, 4]], [[1, 2, 0], [0, 1, 2]], [[2, 5, 2], [1, 6, 8]]);
  testMultiplication("not multiplicable matrices", [[1, 2, 3], [4, 5, 6]], [[1, 2, 0], [0, 1, 2]], "Not Multiplicable");
  testMultiplication("simple multiplicable matrices", [[1, 2, 3], [4, 5, 6]], [[10, 11], [20, 21], [30, 31]], [[140, 146], [320, 335]]);
}

testall();