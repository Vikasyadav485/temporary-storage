// Given a string and a single-character delimiter, returns an array of strings
// obtained by splitting the input string at each occurrence of the delimiter.
// The delimiter must be a single character.
// Examples:
// split("a,b,c", ",") => ["a", "b", "c"]
// split("one:two:three", ":") => ["one", "two", "three"]
// split("hello", ",") => ["hello"]

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function split(sentence, delimiter) {
  let splitedStrings = [];
  let string = '';

  for (let index = 0; index < sentence.length; index++) {

    if (sentence[index] === delimiter) {
      splitedStrings.push(string);
      string = '';
    } else {
      string += sentence[index];
    }
  }
  splitedStrings.push(string);

  return splitedStrings;
}

function composeMessage(discription, sentence, delimiter, actual, expected) {
  const right = `✅ ${discription}`;
  const wrong = `❌ ${discription}
  input    : | ${sentence}, ${delimiter} |
  actual   : [${actual}]
  expected : [${expected}]
  ----------- \n`;

  const message = areEqual(actual, expected) ? right : wrong;

  return message;
}

function testSplitedStringsArray(discription, sentence, delimiter, expected) {
  const actual = split(sentence, delimiter);
  const message = composeMessage(discription, sentence, delimiter, actual, expected);

  console.log(message);
}

function testall() {
  testSplitedStringsArray("splited with comma", "a,b,c", ",", ["a", "b", "c"]);
  testSplitedStringsArray("splited with colan", "one:two:three", ":", ["one", "two", "three"]);
  testSplitedStringsArray("splited with semicolan", "four;five;six", ";", ["four", "five", "six"]);
  testSplitedStringsArray("no delimiter", "hello", ",", ["hello"]);
  testSplitedStringsArray("delimiter at last", "hello,", ",", ["hello", '']);
  testSplitedStringsArray("delimiter at start", ",hello", ",", ["", "hello"]);
  testSplitedStringsArray("empty string", "", ",", [""]);
}

testall();