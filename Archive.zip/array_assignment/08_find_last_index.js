// Given an array of numbers and a element, return the last index in the array
// where element is present else -1
// findLastIndex(["apple", "cake", "tea", "coffee", "tea", "pen"], "tea") => 4
// do not modify input parameters

function findLastIndex(array, element) {
  for (let index = array.length - 1; index >= 0; index--) {
    if (array[index] === element) {
      return index;
    }
  }

  return -1;
}

function composeMessage(discription, array, element, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : [[${array}], ${element}]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? messageForRight : messageForWrong;

  return message;
}

function testFindLastIndex(discription, array, element, expected) {
  const actual = findLastIndex(array, element);
  const message = composeMessage(discription, array, element, actual, expected);

  console.log(message);
}

function testall() {
  testFindLastIndex("simple array with strings only", ["apple", "cake", "tea", "coffee", "tea"], "tea", 4);
  testFindLastIndex("array with strings and numbers", [87, 44, "tea", 87, "tea"], 87, 3);
  testFindLastIndex("doesn't match any element", ["apple", "cake", "tea", "coffee", "tea"], "tata", -1);
  testFindLastIndex("simple array with numbers only", [67, 878, 98, 878, 54], 878, 3);
}

testall();