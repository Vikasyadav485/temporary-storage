/*# Filled Rectangle

## Instructions
Your task is to implement the function `generatePattern(style, dimensions)` that returns a newline-separated string representing a specific pattern. 

For this assignment, you will create a **filled rectangle** pattern. The `style` parameter will be `"filled-rectangle"`, and the `dimensions` parameter will be an array `[columns, rows]` where:
- `columns` is the number of columns in the rectangle.
- `rows` is the number of rows in the rectangle.

The rectangle should be filled with `*` characters. Each row should consist of `columns` number of `*` characters, and there should be `rows` rows in total.

### Special Cases
- If either dimension is `0` (e.g., `[0, X]` or `[X, 0]`), the rectangle is considered empty, and the function should return an **empty string**.

---

### Examples
javascript
generatePattern("filled-rectangle", [5, 3]);
// Output:
*****
*****
*****

generatePattern("filled-rectangle", [2, 4]);
// Output:
**
**
**
**

generatePattern("filled-rectangle", [0, 5]);
// Output: (empty string)

generatePattern("filled-rectangle", [7, 0]);
// Output: (empty string)
---

### Notes
- Each line of the output should be separated by a **newline character (`\n`)**.
- Ensure that the function works for both small and large dimensions.

--- */

// function dontHaveRowOrColumn(dimensions) {
//   return dimensions[0] === 0 || dimensions[1] === 0;
// }

// function generateRow(dimensions) {
//   return "*".repeat(dimensions[0]);
//   // let row = '';

//   // for (let index = 1; index <= dimensions[0]; index++) {
//   //   row += "*";
//   // }
//   // return row;
// }

function filledRectenglePattern(dimensions) {
  if (dimensions[0] === 0 || dimensions [1] === 0) {
    return "";
  }

  let pattern = '';

  for (let index = 1; index < dimensions[1]; index++) {
    pattern += "*".repeat(dimensions[0]) + "\n";
  }
  pattern += "*".repeat(dimensions[0]) ;

  return pattern;
}

function generatePattern(style, dimensions){
  if (style === "filled-rectengle") {
    return filledRectenglePattern(dimensions);
  }
}

function composeMessage(discription, style, dimensions, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : [${style}, [${dimensions}]]
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = actual === expected ? messageForRight : messageForWrong;

  return message;
} 

function testGeneratePattern(discription, style, dimensions, expected) {
  const actual = generatePattern(style, dimensions);
  const message = composeMessage(discription, style, dimensions, actual, expected);

  console.log(message);
}

function testall() {
  testGeneratePattern("with non-zero dimensions", "filled-rectengle", [5, 3], `*****\n*****\n*****`);
  testGeneratePattern("with non- zero dimensions", "filled-rectengle", [2, 4], `**\n**\n**\n**`);
  testGeneratePattern("with zero columns", "filled-rectengle", [0, 5], '');
  testGeneratePattern("with zero rows", "filled-rectengle", [7, 0], '');
}

testall();