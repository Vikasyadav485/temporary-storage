// Write a function that gives first numberOfTerm elements of fibonacci in an array
// fibonacci(5) => [0, 1, 1, 2, 3]
// do not modify input parameters

function areEqual(array1, array2) {
  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function fibonacciSeries(numberOfTerm) {
  let currentTerm = 0;
  let nextTerm = 1;

  for (let index = 2; index <= numberOfTerm; index++) {
    currentTerm = currentTerm + nextTerm;
    nextTerm = currentTerm - nextTerm;
  }

  return currentTerm;
}

function fibonacci(numberOfTerm) {
  let fibonacciArray = [];

  for (let index = 0; index < numberOfTerm; index++) {
    fibonacciArray[index] = fibonacciSeries(index + 1);
  }

  return fibonacciArray;
}

function composeMessage(discription, numberOfTerm, actual, expected) {
  const right = `✅ ${discription}`;
  const wrong = `❌ ${discription}
  input    : | ${numberOfTerm} |
  actual   : ${actual}
  expected : ${expected}
  -----------`;

  const message = areEqual(actual, expected) ? right : wrong;

  return message;
}

function testFibonacci(discription, numberOfTerm, expected) {
  const actual = fibonacci(numberOfTerm);
  const message = composeMessage(discription, numberOfTerm, actual, expected);

  console.log(message);
}

function testall() {
  testFibonacci("fibonacci series", 5, [0, 1, 1, 2, 3]);
  testFibonacci("fibonacci series", 6, [0, 1, 1, 2, 3, 5]);
  testFibonacci("fibonacci series", 10, [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]);
  testFibonacci("fibonacci series", 2, [0, 1]);
  testFibonacci("there is not any zeroth term", 0, []);
}

testall();