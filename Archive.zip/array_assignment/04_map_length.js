// Given an array containing words, return a new array containing length of
// the words.
// mapLengths(["apple", "cat", "Four"]) => [5, 3, 4]
// do not modify input parameters

function checkEquality(array1, array2) {
  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function mapLengths(words) {
  let mappedLengths = [];

  for(let index = 0; index < words.length; index++) {
    mappedLengths.push(words[index].length);
  }

  return mappedLengths;
}

function composeMessage(discription, words, actual, expected) {
  const messageForRight = `✅ ${discription}`;
  const messageForWrong = `❌ ${discription} \n \n input : | [${words}] |
 actual : ${actual} \n expected : ${expected} \n - - - -`;

  const message = checkEquality(actual, expected) ? messageForRight : messageForWrong;

  return message;
}

function testMapLengths(discription, words, expected) {
  const actual = mapLengths(words);
  const message = composeMessage(discription, words, actual, expected);

  console.log(message);
}

function testall(){
  testMapLengths("simple strings", ["apple", "boy", "cat"], [5, 3, 3]);
  testMapLengths("simple strings", ["apple", "boy", "four"], [5, 3, 4]);
  testMapLengths("strings including empty string", ["apple", "boy", ""], [5, 3, 0]);
}

testall();