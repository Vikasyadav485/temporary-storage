/*
  Implement the below function to count number of vowels present in the
  give sentence.
  Examples:
  countVowels("hello world") returns 3
  countVowels("hEllo wOrld") returns 3
*/

function checkVowel(a) {
  if (a === "a" || a === "e" || a === "i" || a === "o" || a === "u") {
    return true;
  }
  if (a === "A" || a === "E" || a === "I" || a === "O" || a === "U") {
    return true;
  }
  return false;
}


function countVowels(sentence) {
  // Implementation here.
  let count = 0;
  for (let index = 0; index < sentence.length; index++) {
    if (checkVowel(sentence[index])) {
      count++;
    }
  }
  return count;

}



function composeMessage(actual, expected) {
  const result = actual === expected ? "✅" : "❌";
  const message = `${result} actual ${actual} expected ${expected}`;
  return message;
}

function testCountVowels(sentence, expected) {
  const actual = countVowels(sentence);
  const message = composeMessage(actual, expected);
  return console.log(message);
}

function testall() {
  testCountVowels("hello world", 3);
  testCountVowels("hEllo wOrld", 3);
  testCountVowels("national herald", 6);
  testCountVowels("total Amount of Interest", 9);
  testCountVowels("hello world", 3);
}

testall();