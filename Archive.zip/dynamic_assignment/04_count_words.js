/*
  Implement the below function to count the number of words
  in the given sentence.

  Rules:
  - A word is defined as a sequence of non-whitespace characters.
  - Whitespace includes SPACE(" "), TAB("\t"), and NEW LINE("\n").
  - Multiple consecutive whitespace characters should be treated
    as a single separator.
  - Leading and trailing whitespace should not affect the word count.

  Example:
  countWords("hello   \t   world \n test")
    -> 3
*/

function checkWhitespace(a) {
  if (a === "\t" || a === "\n" || a === " ") {
    return true;
  }
  return false;
}

function eatNonWhiteSpaces(sentence, i) {
  for (let index = i; index < sentence.length; index++) {
    if (sentence[index] === "\n" || sentence[index] === "\t" || sentence[index] === " ") {
      return index;
    }
  }
}


function eatWhiteSpaces(sentence, i) {
  for (let index = i; index < sentence.length; index++) {
    if (sentence[index] !== "\n" && sentence[index] !== "\t" && sentence[index] !== " ") {
      return index;
    }
  }
}

function countWords(sentence) {
  // Implementation here.
  let wordsCounted = 0;
  for (let index = 0; index <= sentence.length - 1; index++) {
    if (checkWhitespace(sentence[index])) {
      index = eatWhiteSpaces(sentence, index);
    } else {
      index = eatNonWhiteSpaces(sentence, index);
      wordsCounted++;
    }
  }
  return wordsCounted;
}

function composeMessage(actual, expected) {
  const result = actual === expected ? "✅" : "❌";
  const message = `${result} actual ${actual} expected ${expected}`;
  return message;
}

function testCountWords(sentence, expected) {
  const actual = countWords(sentence);
  const message = composeMessage(actual, expected);
  return console.log(message);
}

function testall() {
  testCountWords("hello   \t   world \n test", 3);
  testCountWords("\nhello   \t   world \n test", 3);
  testCountWords("\t hello   \t   world \n test \t", 3);
  testCountWords("\n \t hello   \t   world \n test    ", 3);
}

testall();