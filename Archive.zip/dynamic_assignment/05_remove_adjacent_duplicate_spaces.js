/*
  Implement the below function to replace every run of adjacent SPACE(" ")
  characters with a single SPACE in the given sentence.

  Rules:
  - Consider only the plain SPACE character (" "). Any contiguous sequence
    of one or more SPACE characters should become a single SPACE.
  - Leading and trailing runs of spaces are also collapsed to a single space.
  - Do NOT modify other whitespace characters: TAB("\t") and NEW LINE("\n")
    must remain exactly as they are.
  - Runs of spaces that are separated by other characters (including \t or \n)
    are treated separately and each such run is collapsed independently.

  Examples:
  removeAdjacentDuplicateSpaces("statement      with    two spaces")
    -> "statement with two spaces"
    (multiple spaces between words collapsed to single spaces)

  removeAdjacentDuplicateSpaces("   hello   world   ")
    -> " hello world "
    (leading/trailing runs collapsed to single leading/trailing space)
*/

function spaceRemove(sentence, index) {
  let count = index;
  for (let index1 = index; index1 < sentence.length; index1++) {
    if (sentence[index1] === " ") {
      count = index1;
    } else {
      return count;
    }
  }
  return count;
}

function removeAdjacentDuplicateSpaces(sentence) {
  // Implementation here.
  let newString = "";
  for (let index = 0; index <= sentence.length - 1; index++) {
    if (sentence[index] === " ") {
      index = spaceRemove(sentence, index);
      newString += sentence[index];
    } else {
      newString += sentence[index];
    }
  }
  return newString;
}

function composeMessage(actual, expected) {
  const result = actual === expected ? "✅" : "❌";
  const message = `${result} actual ${actual} expected ${expected}`;
  return message;
}

function testRemoveAdjacentDuplicateSpaces(sentence, expected) {
  const actual = removeAdjacentDuplicateSpaces(sentence);
  const message = composeMessage(actual, expected);
  return console.log(message);
}

function testall() {
  testRemoveAdjacentDuplicateSpaces("statement      with    two spaces", "statement with two spaces");
  testRemoveAdjacentDuplicateSpaces("   hello   world   ", " hello world ");
  testRemoveAdjacentDuplicateSpaces("statement    \n  with    two spaces", "statement \n with two spaces");
  testRemoveAdjacentDuplicateSpaces("statement    \n \t  with    two spaces", "statement \n \t with two spaces");
  testRemoveAdjacentDuplicateSpaces("\t statement    \n \t  with    two spaces \t", "\t statement \n \t with two spaces \t");
}

testall();