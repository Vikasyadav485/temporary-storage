/*
  Implement the below function to trim(remove all leading and trailing 
  whitespaces) from the given sentence.
  A whitespace is SPACE(" "), NEW LINE("\n"), TAB("\t")
  Examples:
  reverseString(" hello world\n") returns "hello world"
*/

function checkWhitespaceLast(sentence) {
  for (let index = sentence.length - 1; index >= 0; index--) {
    if (sentence[index] !== "\t" && sentence[index] !== "\n" && sentence[index] !== " ") {
      return index;
    }
  }
}

function checkWhitespaceStart(sentence) {
  for (let index = 0; index < sentence.length; index++) {
    if (sentence[index] !== "\t" && sentence[index] !== "\n" && sentence[index] !== " ") {
      return index;
    }
  }
}

function trim(sentence) {
  // Implementation here.
  let trimmedString = "";
  const startOfRange = checkWhitespaceStart(sentence);
  const endOfRange = checkWhitespaceLast(sentence);
  console.log(startOfRange, endOfRange);
  for (let index = startOfRange; index <= endOfRange; index++) {
    trimmedString += sentence[index];
  }
  return trimmedString;
}

function composeMessage(actual, expected) {
  const result = actual === expected ? "✅" : "❌";
  const message = `${result}actual${actual}expected${expected}`;
  return message;
}

function testtrimming(sentence, expected) {
  const actual = trim(sentence);
  const message = composeMessage(actual, expected);
  return console.log(message);
}

function testall() {
  testtrimming(" hello world\n", "hello world");
  testtrimming("hello \t world\t", "hello \t world");
  testtrimming("\nhello \t world", "hello \t world");
  testtrimming("\thello \t world ", "hello \t world");
  testtrimming("\thello \n world ", "hello \n world");
  testtrimming("\thello \t \n world\n", "hello \t \n world");
  testtrimming("\t hello \t world ", "hello \t world");
  testtrimming("", "");
  testtrimming("\t ", "");
}

testall();