/*
  Implement the below function to reverse the given sentence.
  Examples:
  reverseString("hello") returns "ollhe"
*/

function reverseString(sentence) {
  let reversedString = "";
  for (let index = sentence.length - 1; index >= 0; index--) {
    reversedString += sentence[index];
  }
  return reversedString;
}

function composeMessage(actual, expected) {
  const result = actual === expected ? "✅" : "❌";
  const message = `${result} actual ${actual} expected ${expected}`;
  return message;
}

function testReverseString(sentence, expected) {
  const actual = reverseString(sentence);
  const message = composeMessage(actual, expected);
  return console.log(message);
}

function testall() {
  testReverseString("hello", "olleh");
  testReverseString("hello world", "dlrow olleh");
  testReverseString("wagon R", "R nogaw");
  testReverseString("extingusher", "rehsugnitxe");
  testReverseString("nana patekar", "raketap anan");
}

testall();