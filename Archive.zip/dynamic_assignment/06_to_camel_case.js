/*
  Implement the below function to convert a string from snake_case
  format into camelCase format.

  Example:
  toCamelCase("hello_wORLd_pro1gram")
    -> "helloWorldPro1gram"
*/

function indexOf(string, char) {
  let index = 0;
  while (index < string.length) {
    if (char === string[index]) {
      return index;
    }
    index++;
  }
  return index--;
}

function upperCase(a) {
  const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const lower = "abcdefghijklmnopqrstuvwxyz";
  for (let index = 0; index < upper.length; index++) {
    if (a === lower[index]) {
      const b = upper[indexOf(lower, a)];
      return b;
    }
  }
  return a;
}

function lowerCase(a) {
  const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const lower = "abcdefghijklmnopqrstuvwxyz";
  for (let index = 0; index < upper.length; index++) {
    if (a === upper[index]) {
      const b = lower[indexOf(upper, a)];
      return b;
    }
  }
  return a;
}

function eatUnderScore(sentence, i) {
  let count = 0;
  for (let index = i; index < sentence.length; index++) {
    if (sentence[index] === "_") {
      count++;
    }
  }
  return count;
}

function toCamelCase(sentence) {
  // Implementation here.
  let newString = "";
  for (let index = 0; index < sentence.length; index++) {
    if (sentence[index] === "_") {
      if (index !== 0 && index !== sentence.length - 1) {
        index = eatUnderScore(sentence, index);
        newString += upperCase(sentence[index]);
      }
    }
    else {
      newString += lowerCase(sentence[index]);
    }
  }
  return newString;
}

function composeMessage(actual, expected) {
  const result = actual === expected ? "✅" : "❌";
  const message = `${result} actual ${actual} expected ${expected}`;
  return message;
}

function testCamelString(sentence, expected) {
  const actual = toCamelCase(sentence);
  const message = composeMessage(actual, expected);
  return console.log(message);
}

function testall() {
  testCamelString("hello_wORLd_pro1gram", "helloWorldPro1gram");
  testCamelString("hello_wORLd_program", "helloWorldProgram");
  testCamelString("_hello_wORLd_program", "helloWorldProgram");
  testCamelString("_hello_wORLd_program_", "helloWorldProgram");
  testCamelString("_hello_wORLd_program_", "helloWorldProgram");
  testCamelString("_hello__wORLd_program_", "helloWorldProgram");
  testCamelString("__hello__wORLd_program_", "helloWorldProgram");
  testCamelString("_hello__wORLd_program_", "helloWorldProgram");
}

testall();