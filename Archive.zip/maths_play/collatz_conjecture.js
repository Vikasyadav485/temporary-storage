const input = 131;
let n = input;
let count = 0;
console.log(n);

while (n !== 1) {
  if (n % 2 === 0){
    n = n / 2;
  }else{
    n = 3 * n + 1;
  }
  console.log(n);
  count++;
}

console.log(count);