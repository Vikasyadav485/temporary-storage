
function bgBlack(text) {
  return "\x1B[40m" + text + "\x1B[0m";
}
function bgRed(text) {
  return "\x1B[41m" + text + "\x1B[0m";
}
function bgGreen(text) {
  return "\x1B[42m" + text + "\x1B[0m";
}
function bgYellow(text) {
  return "\x1B[43m" + text + "\x1B[0m";
}
function bgBlue(text) {
  return "\x1B[44m" + text + "\x1B[0m";
}
function bgMagenta(text) {
  return "\x1B[45m" + text + "\x1B[0m";
}
function bgCyan(text) {
  return "\x1B[46m" + text + "\x1B[0m";
}
function bgWhitehite(text) {
  return "\x1B[47m" + text + "\x1B[0m";
}



function bold(text) {
  return "\x1B[1m" + text + "\x1B[0m";
}

function dim(text) {
  return "\x1B[2m" + text + "\x1B[0m";
}

function italic(text) {
  return "\x1B[3m" + text + "\x1B[0m";
}

function underline(text) {
  return "\x1B[4m" + text + "\x1B[0m";
}

function blink(text) {
  return "\x1B[5m" + text + "\x1B[0m";
}




function custom(text, code) {
  return "\x1B[38;5;" + code + "m" + text + "\x1B[0m";
}

function customBg(text, code) {
  return "\x1B[48;5;" + code + "m" + text + "\x1B[0m";
}

function random(text) {
  const color = Math.floor(Math.random() * (231 - 1 + 1)) + 1;
  return custom(text, color);
}

function randomBg(text) {
  const color = Math.floor(Math.random() * (231 - 1 + 1)) + 1;
  return custom(text, color);
}


console.log(custom(" VIKAS "));