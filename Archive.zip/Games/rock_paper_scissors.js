function confirmation() {
  return confirm("Do you want to play again?");
}

function generator() {
  return (Math.floor(Math.random() * 10)) % 3;
}  

function nameConverter(guessed) {
  switch (guessed) {
    case 0:
      return "🪨 ROCK";
    case 1:
      return "🧾📰PAPER";
    case 2:
      return "✂️ SCISSORS";
  }    
}  

function makeDecision(userGuess, botGuess) {
  const win = "🟢 🏆 YOU WIN 🏆 🟢";
  const lose = "🔴 👎🏻 YOU LOSS 👎🏻 🔴";
  const difference = userGuess - botGuess;

  if (botGuess === userGuess) {
    return "🟡 DRAW  🟡";
  }    

  return (difference === 1 || difference === -2) ? win : lose;
}    

function takeInput() {
  const input = prompt("Rock Paper or Scissors : ");
  return "rps".indexOf(input);
}  

function composeMessage(result, userGuess, botGuess) {

  const title = " ".repeat(10) + result + "\n" + "-".repeat(40);
  const message1 = `\n\n     🤖The bot chose : ${nameConverter(botGuess)}`;
  const message2 = `\n     🐵You chose     : ${nameConverter(userGuess)}`;
  const message3 = "\n\n" + "-".repeat(40);

  return title + message1 + message2 + message3;
}

function game() {
  console.clear();
  const userGuess = takeInput();

  if (userGuess === -1) {
    return console.log("Invalid Input");
  }

  const botGuess = generator();
  const result = makeDecision(userGuess, botGuess);
  const message = composeMessage(result, userGuess, botGuess);

  console.log(message);
  return ;
}

function play() {
  game();

  if (confirmation()) {
    play();
  }
}

play();