const GIFT = "🎁";
const HOUSE = "🏠";
console.clear();

function playAgainConfirmation() {
  return confirm("Do you want to play again?");
}

function display(array) {
  const string = array.join("");
  console.log(string);
}

function findLocations(array, icon) {
  const locations = [];
  for (let index = 8; index < array.length - 8; index++) {
    if (array[index] === icon) {
      locations.push(index);
    }
  }
  return locations;
}

let floor = [["  ", "  ", "🧱", "🧱", "🧱", "🧱", "🧱", "  "],
["🧱", "🧱", "🧱", "🟩", "🟩", "🟩", "🧱", "  "],
["🧱", "🏠", "👦🏻", "🎁", "🟩", "🟩", "🧱", "  "],
["🧱", "🧱", "🧱", "🟩", "🎁", "🏠", "🧱", "  "],
["🧱", "🏠", "🧱", "🧱", "🎁", "🟩", "🧱", "  "],
["🧱", "🟩", "🧱", "🟩", "🏠", "🟩", "🧱", "🧱"],
["🧱", "🎁", "🟩", "🎁", "🟩", "🎁", "🏠", "🧱"],
["🧱", "🟩", "🟩", "🟩", "🏠", "🟩", "🟩", "🧱"],
["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
];

const stringfloor = floor.join("\n");
const array = stringfloor.split(",");
const giftLocations = findLocations(array, GIFT);
const housesLocations = findLocations(array, HOUSE);
const man = array.indexOf("👦🏻");

function userDirection() {
  const input = parseInt(prompt("give the direction"));
  switch (input) {
    case 6: return 1;
    case 4: return -1;
    case 8: return -7;
    case 2: return 7;
    default: return userDirection();
  }
}

function areObstacles(nextPos, move) {
  if (array[nextPos] === "🧱" || nextPos % 7 === 0 || (array[nextPos] === "🎁" && (array[nextPos + move] !== "🟩" && array[nextPos + move] !== "🏠"))) {
    return true;
  }
  return false;
}

function nextPostion(boyPre, array) {
  const move = userDirection();
  const nextPos = boyPre + move;

  if (areObstacles(nextPos, move)) {
    return nextPostion(boyPre, array);
  }

  return nextPos;
}

function hasWon() {
  for (let index = 0; index < housesLocations.length; index++) {
    if (array[housesLocations[index]] !== GIFT) {
      return false;
    }
  }
  return true;
}

function game(array, giftLocations, housesLocations, man) {
  let boyPre = man;
  display(array);

  while (!hasWon()) {
    const boy = nextPostion(boyPre, array);
    array[boy] = "👦🏻";
    array[boyPre] = housesLocations.indexOf(boyPre) !== -1 ? "🏠" : "🟩";

    for (let index = 0; index < giftLocations.length; index++) {
      if (boy === giftLocations[index]) {
        const newGift = (2 * giftLocations[index]) - boyPre;
        array[newGift] = GIFT;
        giftLocations[index] = newGift;
      }
    }
    console.clear();
    display(array);
    boyPre = boy;
  }
  console.log("you won this level.");
}

function play() {
  game(array, giftLocations, housesLocations, man);

  if (playAgainConfirmation()) {
    play();
  }
}

play();