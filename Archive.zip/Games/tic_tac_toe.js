function confirmation() {
  return confirm("Do you want to play again?");
}

function dim(text) {
  return "\x1B[2m" + text + "\x1B[0m";
}

function gridDesign() {
  let grid = `\n  ${dim("01")} | ${dim("02")} | ${dim("03")} \n --------------\n  ${dim("04")} | ${dim("05")} | ${dim("06")} \n --------------\n  ${dim("07")} | ${dim("08")} | ${dim("09")} \n`
  return grid;
}

function areWinnigPositions(inputs) {
  const winning = ["123", "456", "789", "147", "258", "369", "159", "357"];

  for (let index = 0; index < 8; index++) {
    const string = winning[index];

    if (isWon(string, inputs)) {
      return true;
    }
  }

  return false;
}

function isWon(string, inputs) {
  for (let index = 0; index < 3; index++) {
    if (inputs.indexOf(string[index]) === -1) {
      return false;
    }
  }

  return true;
}

function isOccupied(userInputs, input) {
  return userInputs[0].indexOf(input) !== -1 || userInputs[1].indexOf(input) !== -1;
}

function userInput(playerNo, userInputs) {
  const input = parseInt(prompt(`Player ${playerNo}! Where do want to tick...`));
  if (isOccupied(userInputs, input)) {
    console.log("This place has occupied already...")
    return userInput(playerNo, userInputs);
  }

  return input;
}

function choseSymbol(playerNo) {
  return ["❌", "⭕️"][playerNo % 2];
}

function gridChange(grid, input, playerNo) {
  const icon = "0" + input;
  return grid.replace(icon, choseSymbol(playerNo));
}

function main() {
  const userInputs = [[], []];
  let grid = gridDesign();
  console.log(grid);

  for (let index = 0; index < 9; index++) {
    const playerNo = index % 2;
    const input = userInput(playerNo + 1, userInputs);
    grid = gridChange(grid, input, playerNo);
    userInputs[playerNo] += input;

    console.clear();
    console.log(grid);

    if (areWinnigPositions(userInputs[playerNo])) {
      return `Player ${playerNo + 1} Won The Match...`;
    }
  }
  return "     Draw";
}

function play() {
  console.clear();
  const grid = main();
  console.log(grid);

  if (confirmation()) {
    play();
  }

}

play();