function boloBe(text) {
  return console.log(text);
}

function tekeInput() {
  const response = prompt("Enter your guessed number : ");
  return parseInt(response);
}

function confirmation() {
  return confirm("Do you want to play again?");
}

function composeMessage(inputNum, secretNum) {
  const large = "🔁 It's too large.."
  const less = "🔁 It's to small..."
  return inputNum > secretNum ? large : less;
}


function generateChances(chance,secretNum) {
  const loosingMessage = `The secret number was : ${secretNum} \n             👎🏻 YOU LOSE`;
  return chance > 1 ? game(chance - 1,secretNum) : boloBe(loosingMessage);
}

function generateSecretNum() {
  return Math.floor(Math.random() * 100);
}

function game(chance,secretNum) {
  const inputNum = tekeInput();

  if (inputNum === secretNum) {
    return boloBe("          🏆 YOU WIN 🏆");
  } 
  boloBe(composeMessage(inputNum, secretNum, chance));

  return generateChances(chance, secretNum);
}


function gamePlay() {
  console.clear();
  const secretNum = generateSecretNum();
  game(5, secretNum);

  if (confirmation()) {
    gamePlay();
  }
}

gamePlay();