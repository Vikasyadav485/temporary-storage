function dim(text){
    return '\x1B[2m'+ text + '\x1B[0m';
}
function playAgainConfirmation() {
  return confirm("Do you want to play again?");
}

function delay() {
  for (let index = 0; index < 800000000; index++) {
  }
  console.clear();
  return;
}

const rouletteString = `
                     🐶   🐱
                 🐔   ${dim("12")} ${dim("01")}   🦊
                   ${dim("11")}       ${dim("02")}
               🐵 ${dim("10")}    🐲   ${dim("03")} 🐻
                      🐲⭐️🐲
               🐸 ${dim("09")}    🐲   ${dim("04")} 🐼
                   ${dim("08")}       ${dim("05")}
                 🐷   ${dim("07")} ${dim("06")}   🐯
                     🐮   🦁`;

function emojiFinder(index) {
  const a = ["🐱", "🦊", "🐻", "🐼", "🐯", "🦁", "🐮", "🐷", "🐸", "🐵", "🐔", "🐶"];
  return a[index];
}

function centerChange(index) {
  return index % 2 ? "⭐️" : "🌟";
}

function noOfRounds() {
  return Math.floor(Math.random() * 10) % 5;
}

function pointer() {
  return (Math.floor(Math.random() * 100) % 12) + 1;
}

function noToStringSymbol(number){
    if(number < 10){
        return "0" + number;
    }
    return "" + number;
}

function ballRotations(rounds, pointed){
    for (let index = 0; index <= rounds; index++) {
    if (index < rounds) {
      moving(13);
    } else {
      moving(pointed + 1)
    }
  }
}

function moving(pointed) {
  let rouletteStringCopy = rouletteString;
  for (let index = 1; index < pointed; index++) {
    const numSymbol = noToStringSymbol(index);
    const sideIconReplaced = rouletteStringCopy.replace(numSymbol, "👑");
    const centerIconChanged = sideIconReplaced.replace("⭐️", centerChange(index));

    console.log("\n The rollete is rolling.....");

    if (index < pointed) {
      delay();
    }
    
    console.log(centerIconChanged);
  }
}

function isMatched(inputs, pointed) {
  return inputs.indexOf(pointed) + 1;
}

function isValid(input) {
  return input < 13 && input > 0;
}

function inputs() {
  const playerCount = prompt("\n❓ How many people want to play : ");
  const players = parseInt(playerCount);
  const inputs = [];
  let index = 1;

  while (index <= players) {
    const input = prompt(`🙋‍♂️ Player ${index}! Enter your lucky number : `);
    if (isValid(input)) {
      inputs.push(parseInt(input));
      index++;
    } 
  }
  return inputs;
}

function winnerStatement(winner, inputs) {
  if (winner === 0) {
    return "\n        👎🏻 🟡 NO ONE WON THE MATCH 🟡 👎🏻         "
  }
  return `\n     🟢 🏵️ 🏆 Player ${winner}! WON THE MATCH 🏆 🏵️ 🟢     `
}

function composeMessage(winner, inputs, pointed) {
  const title = winnerStatement(winner, inputs);
  const underline = "\n" + "-".repeat(title.length);
  let message = "\n\n";

  for (let index = 0; index < inputs.length; index++) {
    message += `🙋‍♂️  Player ${index + 1} Chose ${emojiFinder(inputs[index] - 1)} \n`
  }

  const message4 = `\n ACTUAL IS ${emojiFinder(pointed - 1)}`

  return title + underline + message + message4 + underline;
}

function description(){
  const heading = "DESCRIPTION :- \n" + "-".repeat(12);
  const rule1 = "\n 1. Max. 3 players should play.";
  const rule2 = "\n 2. Chose your lucky number between 1 and 12."

  return heading + rule1 + rule2 + rouletteString;
}

function roulette() {
  console.clear();
  console.log(description());
  const pointed = pointer();
  const rounds = noOfRounds();
  const input = inputs();

  ballRotations(rounds, pointed);
  const winner = isMatched(input, pointed);
  const message = composeMessage(winner, input, pointed);

  console.log(message);
  return;
}

function play() {
  roulette();

  if (playAgainConfirmation()) {
    play();
  }
}

play();