const INTEGER_START = "i";
const LIST_START = "l";
const COLON = ":";
const INTEGER_END = "e";
const LIST_END = "e";

function areTypesNotSame(array1, array2) {
  return typeof array1 !== typeof array2;
}

function areLengthsNotEqual(array1, array2) {
  return array1.length !== array2.length;
}

function areDeepEqual(array1, array2) {
  if (areTypesNotSame(array1, array2)) {
    return false;
  }
  if (areLengthsNotEqual(array1, array2)) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (typeof array1[index] === "object") {
      return areDeepEqual(array1[index], array2[index]);
    }

    if (array1[index] !== array2[index]) {
      return false
    }
  }

  return true;
}

function encode(data) {
  switch (typeof (data)) {
    case "number":
      return INTEGER_START + data + INTEGER_END;
    case "string":
      return data.length + COLON + data;
    case "object":
      return encodeArray(data);
  }
}

function encodeArray(data) {
  let dataString = LIST_START;
  for (let index = 0; index < data.length; index++) {
    dataString += encode(data[index]);
  }
  return dataString + LIST_END;
}

function decodeArray(data) {
  let array = [];
  let dataSegment = data.slice(1);
  console.log(dataSegment);

  while (dataSegment.length > 1) {
    const decodedArray = decode(dataSegment);
    array.push(decodedArray[1]);
    dataSegment = dataSegment.slice(decodedArray[0]);
    array = array.slice(array.indexOf(LIST_END));
  }
  // const metaDeta = [dataSegment.IndexOf(LIST_END), array];
  console.log(array);
  return array;
}

function decodeNumber(data) {
  const length = data.indexOf(INTEGER_END);
  const decodedString = data.slice(1, length);
  const metaDeta = [length, parseInt(decodedString)];
  return metaDeta;
}

function decodedString(data) {
  const stringStart = data.indexOf(COLON) + 1;
  const length = parseInt(data.slice(0, stringStart - 1));
  const metaDeta = [length + stringStart, data.slice(stringStart, length + stringStart)]
  return metaDeta;
}

function decode(data) {
  switch (data[0]) {
    case INTEGER_START:
      return decodeNumber(data);
    case LIST_START:
      return decodeArray(data);
    default:
      return decodedString(data);
  }
}

function underline(text) {
  return "-".repeat(text.length);
}

function composeMessage(data, description, actual, expected) {
  if (areDeepEqual(actual, expected)) {
    return `✅ ${description}`;
  }
  return `❌ ${description} \n   ${underline(description)}
  input    : ${data}
  actual   : ${actual}
  expected : ${expected}`
}

function testEncode(description, data, expected) {
  const actual = encode(data);
  const message = composeMessage(data, description, actual, expected);
  console.log(message);
}

function testDecode(description, data, expected) {
  const actual = decode(data)[1];
  const message = composeMessage(data, description, actual, expected);
  console.log(message);
}

function testall() {
  console.clear();
  // testEncode("positive number", 123, "i123e");
  // testEncode("negative number", -42, "i-42e");
  // testEncode("zero", 0, "i0e");
  // // testEncode("leading zero", 01, "i01e");
  // testEncode("string", "hello", "5:hello");
  // testEncode("empty string", "", "0:");
  // testEncode("multi word string", "hello world", "11:hello world");
  // testEncode("special chars string", "special!@#$chars", "16:special!@#$chars");
  // testEncode("nested array", ["apple", 123, ["banana", -5]], "l5:applei123el6:bananai-5eee");
  // testEncode("empty array", [], "le");
  // testEncode("nested array", [0, "", ["test"]], "li0e0:l4:testee");
  // testEncode("array in an empty array", ["", 0, []], "l0:i0elee");
  // testEncode("array of strings", ["one", ["two", ["three"]]], "l3:onel3:twol5:threeeee");

  // testDecode("positive number", "i123e", 123);
  // testDecode("negative number", "i-42e", -42);
  // testDecode("zero", "i0e", 0);
  // testDecode("simple string", "5:hello", "hello");
  // testDecode("empty string", "0:", "");
  // testDecode("multi word string", "11:hello world", "hello world");
  // testDecode("array", "l5:applei123el6:bananai-5eee", ["apple", 123, ["banana", -5]]);
  // testDecode("array", "l5:applei123ee", ["apple", 123]);
  // testDecode("array", "li45ee", [45]);
  // testDecode("empty array", "le", []);
  // testDecode("array", "li45e5:helloe", [45, "hello"]);
  // testDecode("array","li0e0:l4:testee", [0, "", ["test"]]);
  // testDecode("array","l0:i0elee", ["", 0, []]);
  // testDecode("array of strings", "l3:onel3:twol5:threeeee", ["one", ["two", ["three"]]]);
  // testDecode("nested empty  array", "llleee", [[[]]]);
  testDecode("array", "llelee", [[], []]);
}

testall();