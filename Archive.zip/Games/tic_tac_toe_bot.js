function confirmation() {
  return confirm("Do you want to play again?");
}

function dim(text) {
  return "\x1B[2m" + text + "\x1B[0m";
}

function gridDesign() {
  let grid = `\n  ${dim("01")} | ${dim("02")} | ${dim("03")} \n --------------\n  ${dim("04")} | ${dim("05")} | ${dim("06")} \n --------------\n  ${dim("07")} | ${dim("08")} | ${dim("09")} \n`
  return grid;
}

function isOccupied(usersInputs, input) {
  return usersInputs[0].indexOf(input) !== -1 || usersInputs[1].indexOf(input) !== -1;
}

function botRandomThought(usersInputs) {
  const random = Math.floor(Math.random() * 10);
  if (random === 0 || isOccupied(usersInputs, random)) {
    return botRandomThought(usersInputs);
  }

  return random;
}

function bot1(usersInputs) {
  const winning = ["123", "456", "789", "147", "258", "369", "159", "357"];

  for (let index = 0; index < 8; index++) {
    const string = winning[index];
    let count = 0;
    let remaining = string[2];
    for (let index = 0; index < 3; index++) {
      
      if (usersInputs[1].indexOf(string[index]) !== -1) {
        count++ ;
      } else {
        remaining = string[index];
      }
      
      if (count === 2 && !(isOccupied(usersInputs, remaining))) {
        console.log("bot");
        return remaining;
      }
    }
  }
  
  for (let index = 0; index < 8; index++) {
    const string = winning[index];
    let count = 0;
    let remaining = string[2];
    for (let index = 0; index < 3; index++) {
      
      if (usersInputs[0].indexOf(string[index]) !== -1) {
        count++ ;
      } else {
        remaining = string[index];
      }
      
      if (count === 2 && !(isOccupied(usersInputs, remaining))) {
        console.log("user");
        return remaining;
      }
    }
  }
  
  if(!isOccupied(usersInputs, 1)){
    return 1;
  }else if(!isOccupied(usersInputs, 3)){
    return 3;
  }else if(!isOccupied(usersInputs, 7)){
    return 7;
  }else if(!isOccupied(usersInputs, 9)){
    return 9;
  }

  return botRandomThought(usersInputs);
}

function areWinnigPositions(inputs) {
  const winning = ["123", "456", "789", "147", "258", "369", "159", "357"];

  for (let index = 0; index < 8; index++) {
    const string = winning[index];

    if (isWon(string, inputs)) {
      return true;
    }
  }

  return false;
}

function isWon(string, inputs) {
  for (let index = 0; index < 3; index++) {
    if (inputs.indexOf(string[index]) === -1) {
      return false;
    }
  }

  return true;
}

function userInput(playerNo, usersInputs) {
  let input = 0;
  if (playerNo === 1) {
    input = parseInt(prompt(`Player ${playerNo}! Where do want to tick...`));
    if (isOccupied(usersInputs, input)) {
      console.log("This place has occupied already...");
      return userInput(playerNo, usersInputs);
    }
  } else {
    input = bot1(usersInputs);
  }

  return input;
}

function choseSymbol(playerNo) {
  return ["❌", "⭕️"][playerNo % 2];
}

function gridChange(grid, input, playerNo) {
  const icon = "0" + input;
  return grid.replace(icon, choseSymbol(playerNo));
}

function main() {
  const usersInputs = [[], []];
  let grid = gridDesign();
  console.log(grid);

  for (let index = 0; index < 9; index++) {
    const playerNo = index % 2;
    const input = userInput(playerNo + 1, usersInputs);
    grid = gridChange(grid, input, playerNo);
    usersInputs[playerNo] += input;

    console.clear();
    console.log(usersInputs[0], usersInputs[1]);
    console.log(grid);

    if (areWinnigPositions(usersInputs[playerNo])) {
      return `Player ${playerNo + 1} Won The Match...`;
    }
  }
  return "     Draw";
}

function play() {
  console.clear();
  const grid = main();
  console.log(grid);

  if (confirmation()) {
    play();
  }

}

play();